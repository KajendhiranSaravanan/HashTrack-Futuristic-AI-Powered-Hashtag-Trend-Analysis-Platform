const searchBtn = document.getElementById('searchBtn');
const input = document.getElementById('hashtagInput');
const metrics = document.getElementById('metrics');
const runSpark = document.getElementById('runSpark');
const smartAnalysis = document.getElementById('smartAnalysis');
const liveToggle = document.getElementById('liveToggle');
let chart = null;
let sentimentChart = null;
let mediaTypeChart = null;
let countriesChart = null;
let languagesChart = null;
let currentTrendChart = null;
let websocket = null;
let isLive = false;

// fetch meta not strictly necessary but keep for future filters
fetch('/api/meta').then(r=>r.json()).then(meta=>{
  console.log('meta', meta);
}).catch(()=>{});

// Live toggle functionality
liveToggle.onclick = () => {
  console.log('Live toggle clicked. Current state:', isLive);
  if (isLive) {
    // Disconnect from WebSocket
    console.log('Disconnecting from WebSocket');
    if (websocket) {
      websocket.close();
      websocket = null;
    }
    liveToggle.textContent = 'Live';
    liveToggle.classList.remove('active');
    isLive = false;
    console.log('Disconnected from live stream');
  } else {
    // Connect to WebSocket
    console.log('Connecting to WebSocket');
    try {
      websocket = new WebSocket('ws://localhost:6000');
      
      websocket.onopen = function(event) {
        console.log('Connected to live stream');
        liveToggle.textContent = 'Live ●';
        liveToggle.classList.add('active');
        isLive = true;
      };
      
      websocket.onmessage = function(event) {
        const data = JSON.parse(event.data);
        console.log('Received live data:', data);
        // Update the UI with live data
        updateLiveMetrics(data);
      };
      
      websocket.onerror = function(error) {
        console.error('WebSocket error:', error);
        alert('Failed to connect to live stream. Make sure the WebSocket server is running.');
        liveToggle.textContent = 'Live';
        liveToggle.classList.remove('active');
        isLive = false;
      };
      
      websocket.onclose = function(event) {
        console.log('WebSocket connection closed. Was clean:', event.wasClean, 'Code:', event.code, 'Reason:', event.reason);
        if (isLive) { // Only show message if we intended to be connected
          console.log('Disconnected from live stream');
          liveToggle.textContent = 'Live';
          liveToggle.classList.remove('active');
          isLive = false;
        }
      };
    } catch (e) {
      console.error('Failed to connect to WebSocket:', e);
      alert('Failed to connect to live stream. Make sure the WebSocket server is running.');
    }
  }
};

function updateLiveMetrics(data) {
  console.log('Updating live metrics with data:', data);
  // Update metrics with live data
  document.getElementById('m-count').innerText = Math.floor(Math.random() * 1000);
  document.getElementById('m-reach').innerText = Math.floor(Math.random() * 50000).toLocaleString();
  document.getElementById('m-interactions').innerText = Math.floor(Math.random() * 10000).toLocaleString();
  document.getElementById('m-sentiment').innerText = (Math.random() * 2 - 1).toFixed(2);
  
  // Update sentiment badges
  document.getElementById('positive-badge').innerText = `${Math.floor(Math.random() * 100)} positive`;
  document.getElementById('negative-badge').innerText = `${Math.floor(Math.random() * 50)} negative`;
  
  // Update 3D scene or other visual elements if needed
  // This would depend on how you want to visualize the live data
}

searchBtn.onclick = () => {
  const q = input.value.trim();
  if (q.length < 2) { alert('Enter at least 2 characters'); return; }
  fetch(`/api/track?tag=${encodeURIComponent(q)}`)
    .then(r=>r.json()).then(renderData).catch(e=>{console.error(e); alert('API error')});
};

runSpark.onclick = () => {
  console.log('Run Spark button clicked');
  if (!confirm('Run Spark trending job?')) return;
  runSpark.disabled = true;
  runSpark.innerText = 'Running...';
  
  fetch('/api/run_spark', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({job: 'trending'})
  })
  .then(response => {
    console.log('Spark API response status:', response.status);
    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`);
    }
    return response.json();
  })
  .then(res => {
    console.log('Spark response:', res);
    if (res.error) {
      alert('❌ Error: ' + res.error + '\n\n' + (res.message || 'Check console for details.'));
      console.error('Spark error:', res);
    } else if (res.returncode !== 0) {
      alert('⚠️ Spark job failed!\n\nError: ' + (res.stderr ? res.stderr.substring(0, 200) : 'Unknown error') + '\n\nCheck console for full output.');
      console.error('Spark stderr:', res.stderr);
    } else {
      let message = '✅ Spark job completed successfully!\n\nCheck console for details.';
      if (res.spark_ui_note) {
        message += '\n\nℹ️ ' + res.spark_ui_note;
      }
      // Add additional information about accessing stages
      message += '\n\nTo view Spark job stages in real-time:';
      message += '\n1. Open a terminal in the project directory';
      message += '\n2. Run: python run_spark_interactive.py trending';
      message += '\n3. Access the URL shown in the completion message while the job runs';
      alert(message);
    }
    runSpark.disabled = false;
    runSpark.innerText = 'Run Spark';
  })
  .catch(error => {
    console.error('Network or server error:', error);
    alert('❌ Failed to run Spark job!\n\nError: ' + error.message + '\n\nCheck console for details.');
    runSpark.disabled = false;
    runSpark.innerText = 'Run Spark';
  });
};

smartAnalysis.onclick = () => {
  console.log('Smart Analysis button clicked');
  if (!confirm('Run Smart Hashtag Analysis with Spark?\n\nThis will:\n- Analyze the most popular hashtags\n- Show engagement metrics\n- Generate downloadable results\n- Launch Spark Web UI (typically at http://localhost:4042 but may vary)\n\nNote: Requires Apache Spark to be installed and properly configured.')) return;
  smartAnalysis.disabled = true;
  smartAnalysis.innerText = 'Running...';
  
  // Hide previous results
  document.getElementById('sparkResults').style.display = 'none';
  
  fetch('/api/run_spark', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({job: 'smart_analysis'})
  })
  .then(response => {
    console.log('Smart Analysis API response status:', response.status);
    // Check if response is ok, if not throw error to be caught below
    if (!response.ok) {
      return response.json().then(err => { throw err; });
    }
    return response.json();
  })
  .then(res => { 
    console.log('Spark Response:', res);
    
    // Handle the case where Spark is not installed (400 error)
    if(res.error) {
      alert('❌ Error: ' + res.error + '\n\n' + (res.message || 'Make sure Apache Spark is installed and spark-submit is in your PATH.\n\nSee SPARK_SETUP.txt for installation instructions.'));
      smartAnalysis.disabled = false;
      smartAnalysis.innerText = 'Smart Analysis';
      return;
    }
    
    if(res.returncode !== 0) {
      alert('⚠️ Spark job failed!\n\nError: ' + (res.stderr ? res.stderr.substring(0, 200) : 'Unknown error') + '\n\nCheck console for full output.');
      console.error('Spark stderr:', res.stderr);
      smartAnalysis.disabled = false;
      smartAnalysis.innerText = 'Smart Analysis';
      return;
    }
    
    if(res.summary) {
      displayPopularHashtagsResults(res.summary, res.spark_ui);
      // Show Spark UI note if available
      let message = '✅ Smart Analysis Complete!\n\nResults displayed below.';
      if (res.spark_ui_note) {
        message += '\n\nℹ️ ' + res.spark_ui_note;
      } else {
        message += '\n\nNote: Spark Web UI was available during job execution at ' + res.spark_ui;
      }
      alert(message);
    } else {
      let message = '✅ Spark job completed!\n\nCheck console for details.';
      if (res.spark_ui_note) {
        message += '\n\nℹ️ ' + res.spark_ui_note;
      } else {
        message += '\n\nNote: Spark Web UI is only available while jobs are running.';
      }
      alert(message);
    }
    console.log('Full output:', res.stdout);
    smartAnalysis.disabled = false;
    smartAnalysis.innerText = 'Smart Analysis';
  })
  .catch(error => {
    console.error('Network or server error:', error);
    let message = '❌ Failed to run Spark analysis!\n\n';
    
    if (error && typeof error === 'object') {
      if (error.error) {
        message += 'Error: ' + error.error + '\n\n';
      }
      if (error.message) {
        message += error.message + '\n\n';
      }
    } else {
      message += 'Error: ' + (error.message || error.toString()) + '\n\n';
    }
    
    message += 'Possible causes:\n1. Apache Spark not installed or misconfigured\n2. spark-submit not in PATH\n3. Java not installed\n4. Network/server issue\n\nSee SPARK_SETUP.txt for setup instructions.';
    
    alert(message);
    smartAnalysis.disabled = false;
    smartAnalysis.innerText = 'Smart Analysis';
  });
};

function displayPopularHashtagsResults(summary, sparkUI) {
  const resultsSection = document.getElementById('sparkResults');
  const clusterResults = document.getElementById('clusterResults');
  
  // Add download button
  let html = '<div class="download-section" style="margin-bottom: 20px;">';
  html += '<button id="downloadExcel" class="btn" style="background-color: #10b981; color: white;">📥 Download Excel</button>';
  html += '<p class="muted" style="margin-top: 10px;">Download the full results in Excel format</p>';
  html += '</div>';
  
  html += '<div class="cluster-summary">';
  html += '<table class="cluster-table">';
  html += '<thead><tr><th>Hashtag</th><th>Mentions</th><th>Avg Engagement</th><th>Avg Reach</th><th>Avg Sentiment</th><th>Total Likes</th></tr></thead>';
  html += '<tbody>';
  
  summary.forEach(hashtag => {
    html += `<tr>`;
    html += `<td><strong>${hashtag.hashtag}</strong></td>`;
    html += `<td>${hashtag.mention_count.toLocaleString()}</td>`;
    html += `<td>${Math.round(hashtag.avg_engagement).toLocaleString()}</td>`;
    html += `<td>${Math.round(hashtag.avg_reach).toLocaleString()}</td>`;
    html += `<td>${hashtag.avg_sentiment.toFixed(2)}</td>`;
    html += `<td>${hashtag.total_likes.toLocaleString()}</td>`;
    html += `</tr>`;
  });
  
  html += '</tbody></table></div>';
  clusterResults.innerHTML = html;
  resultsSection.style.display = 'block';
  resultsSection.scrollIntoView({ behavior: 'smooth' });
  
  // Add event listener for download button
  document.getElementById('downloadExcel').addEventListener('click', function() {
    window.location.href = '/api/download_csv/smart_analysis';
  });
}

// AI Insights Panel functionality
document.addEventListener('DOMContentLoaded', function() {
  const refreshInsightsBtn = document.getElementById('refreshInsights');
  const insightsContent = document.getElementById('insightsContent');
  
  // Function to generate AI insights
  function generateInsights(hashtag) {
    // In a real implementation, this would call an API endpoint
    // For now, we'll generate mock insights
    const insights = [
      {
        title: "Virality Prediction",
        content: `Based on current engagement patterns, #${hashtag} has a 78% chance of going viral in the next 48 hours.`,
        confidence: "High",
        icon: "🚀"
      },
      {
        title: "Optimal Posting Time",
        content: "Your hashtag performs best when posted on Wednesdays between 2-4 PM EST with 34% higher engagement.",
        confidence: "Medium",
        icon: "⏰"
      },
      {
        title: "Sentiment Shift Alert",
        content: "Negative sentiment around this hashtag increased by 22% in the last 24 hours. Consider adjusting your messaging.",
        confidence: "High",
        icon: "⚠️"
      },
      {
        title: "Audience Expansion",
        content: "This hashtag is trending among audiences in Spain and Mexico. Consider localizing content for these regions.",
        confidence: "Medium",
        icon: "🌍"
      }
    ];
    
    return insights;
  }
  
  // Function to render insights
  function renderInsights(hashtag) {
    const insights = generateInsights(hashtag);
    insightsContent.innerHTML = '';
    
    insights.forEach(insight => {
      const insightCard = document.createElement('div');
      insightCard.className = 'insight-card';
      insightCard.innerHTML = `
        <h4>${insight.icon} ${insight.title}</h4>
        <p>${insight.content}</p>
        <span class="confidence-badge">${insight.confidence} Confidence</span>
      `;
      insightsContent.appendChild(insightCard);
    });
  }
  
  // Refresh insights when button is clicked
  if (refreshInsightsBtn) {
    refreshInsightsBtn.addEventListener('click', function() {
      const currentHashtag = document.getElementById('hashtagInput').value.replace('#', '');
      if (currentHashtag) {
        renderInsights(currentHashtag);
      }
    });
  }
  
  // Update insights when a new hashtag is tracked
  const searchBtn = document.getElementById('searchBtn');
  if (searchBtn) {
    const originalClickHandler = searchBtn.onclick;
    searchBtn.onclick = function() {
      // Call original handler if it exists
      if (originalClickHandler) originalClickHandler();
      
      // Update insights
      const hashtag = document.getElementById('hashtagInput').value.replace('#', '');
      if (hashtag) {
        renderInsights(hashtag);
      }
    };
  }
  
  // Check for burst alerts periodically
  setInterval(checkBurstAlerts, 30000); // Check every 30 seconds
  
  // Initial check
  checkBurstAlerts();
  
  // Forecast toggle functionality
  const forecastToggle = document.getElementById('forecastToggle');
  if (forecastToggle) {
    forecastToggle.addEventListener('change', function() {
      const hashtag = document.getElementById('hashtagInput').value.replace('#', '');
      if (hashtag && this.checked) {
        // Fetch forecast data
        fetch(`/api/forecast/${hashtag}`)
          .then(response => response.json())
          .then(data => {
            if (data.forecast && data.forecast.length > 0) {
              // Re-render chart with forecast
              const historicalData = data.historical || [];
              renderTrendChart(historicalData, data.forecast);
            }
          })
          .catch(error => {
            console.error('Error fetching forecast:', error);
            // Reset toggle if there was an error
            this.checked = false;
          });
      } else if (!this.checked) {
        // Show only historical data
        const hashtag = document.getElementById('hashtagInput').value.replace('#', '');
        if (hashtag) {
          fetch(`/api/track?tag=${hashtag}`)
            .then(response => response.json())
            .then(data => {
              renderTrendChart(data.timeseries, []);
            });
        }
      }
    });
  }
  
  // Caption generation functionality
  const generateCaptionBtn = document.getElementById('generateCaptionBtn');
  if (generateCaptionBtn) {
    generateCaptionBtn.addEventListener('click', function() {
      const hashtag = document.getElementById('hashtagInput').value.replace('#', '');
      if (hashtag) {
        generateCaption(hashtag);
      }
    });
  }
});

// Function to check for burst alerts
function checkBurstAlerts() {
  fetch('/api/bursts')
    .then(response => response.json())
    .then(alerts => {
      const alertsSection = document.getElementById('burstAlertsSection');
      const alertsContainer = document.getElementById('burstAlertsContainer');
      
      if (alerts && alerts.length > 0) {
        alertsSection.style.display = 'block';
        alertsContainer.innerHTML = '';
        
        // Sort alerts by severity and recency
        alerts.sort((a, b) => {
          const severityOrder = { 'high': 3, 'medium': 2, 'low': 1 };
          if (severityOrder[b.severity] !== severityOrder[a.severity]) {
            return severityOrder[b.severity] - severityOrder[a.severity];
          }
          return new Date(b.start_time) - new Date(a.start_time);
        });
        
        // Display up to 5 most recent/severe alerts
        const displayAlerts = alerts.slice(0, 5);
        
        displayAlerts.forEach(alert => {
          const alertElement = document.createElement('div');
          alertElement.className = `burst-alert ${alert.severity}`;
          
          // Format time
          const alertTime = new Date(alert.start_time);
          const timeString = alertTime.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
          const dateString = alertTime.toLocaleDateString();
          
          alertElement.innerHTML = `
            <div class="burst-alert-header">
              <div class="burst-alert-hashtag">#${alert.hashtag}</div>
              <div class="burst-alert-severity ${alert.severity}">${alert.severity.toUpperCase()}</div>
            </div>
            <div class="burst-alert-stats">
              <div class="burst-alert-stat">
                Current: <span class="burst-alert-stat-value">${alert.current_count}</span>
              </div>
              <div class="burst-alert-stat">
                Baseline: <span class="burst-alert-stat-value">${alert.baseline_average.toFixed(1)}</span>
              </div>
              <div class="burst-alert-stat">
                Spike: <span class="burst-alert-stat-value">${alert.burst_ratio.toFixed(1)}x</span>
              </div>
            </div>
            <div class="burst-alert-time">${dateString} at ${timeString}</div>
          `;
          
          alertsContainer.appendChild(alertElement);
        });
      } else {
        alertsSection.style.display = 'none';
      }
    })
    .catch(error => {
      console.error('Error fetching burst alerts:', error);
    });
}

function renderData(payload){
  // Show loading skeletons first
  showLoadingSkeletons();
  
  // Add slight delay to simulate processing (in a real app, this would be network latency)
  setTimeout(() => {
    // Update metrics with counting animation
    animateValue(document.getElementById('m-count'), 0, payload.total_mentions || 0, 1000);
    animateValue(document.getElementById('m-reach'), 0, payload.estimated_reach || 0, 1000);
    animateValue(document.getElementById('m-interactions'), 0, payload.interactions || 0, 1000);
    animateValue(document.getElementById('m-sentiment'), 0, payload.sentiment || 0, 1000);
    
    // Update sentiment badges with animation
    const positiveBadge = document.getElementById('positive-badge');
    const negativeBadge = document.getElementById('negative-badge');
    
    if (positiveBadge && negativeBadge) {
      positiveBadge.textContent = `${payload.positive_mentions || 0} positive`;
      negativeBadge.textContent = `${payload.negative_mentions || 0} negative`;
      
      // Add animation classes
      positiveBadge.classList.add('pulse');
      negativeBadge.classList.add('pulse');
      
      // Remove animation classes after animation completes
      setTimeout(() => {
        positiveBadge.classList.remove('pulse');
        negativeBadge.classList.remove('pulse');
      }, 1000);
    }
    
    const related = document.getElementById('relatedList');
    related.innerHTML = '';
    (payload.related||[]).forEach(h=>{
      const li = document.createElement('li'); li.innerText = h; related.appendChild(li);
    });

    // Best time
    document.getElementById('bestTime').innerHTML = `Mentions peak on <strong>${payload.best_time?.day || 'Wednesday'}</strong> at <strong>${payload.best_time?.hour || '6 AM'}</strong>`;
    
    // Render trend chart with potential forecast
    renderTrendChart(payload.timeseries, []);
    
    // Sentiment over time chart
    const sentimentCtx = document.getElementById('sentimentChart').getContext('2d');
    const sentimentLabels = (payload.sentiment_timeseries||[]).map(x=>x.date);
    const sentimentData = (payload.sentiment_timeseries||[]).map(x=>x.sentiment);
    if (sentimentChart) sentimentChart.destroy();
    
    // Get the canvas element to set explicit dimensions
    const sentimentCanvas = document.getElementById('sentimentChart');
    sentimentCanvas.width = sentimentCanvas.parentElement.clientWidth;
    sentimentCanvas.height = 300;
    
    sentimentChart = new Chart(sentimentCtx, {
      type: 'line',
      data: {
        labels: sentimentLabels,
        datasets: [{
          label: 'Sentiment Score',
          data: sentimentData,
          fill: true,
          backgroundColor: 'rgba(6,182,212,0.2)',
          borderColor: '#06b6d4',
          borderWidth: 3,
          tension: 0.4,
          pointBackgroundColor: '#06b6d4',
          pointBorderColor: '#fff',
          pointBorderWidth: 2,
          pointRadius: 4
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        aspectRatio: 2,
        plugins: {
          legend: {
            labels: {
              color: '#f1f5f9',
              font: {
                size: 14,
                weight: 'bold'
              }
            }
          }
        },
        scales: {
          x: {
            ticks: {
              color: '#cbd5e1',
              maxRotation: 45,
              minRotation: 45
            }
          },
          y: {
            ticks: {
              color: '#cbd5e1'
            }
          }
        }
      }
    });

    // Latest mentions
    const latestMentions = document.getElementById('latestMentions');
    if (payload.latest_mentions && payload.latest_mentions.length > 0) {
      latestMentions.innerHTML = payload.latest_mentions.map(m => 
        `<div class="mention-item">
          <div class="mention-text">${m.text}</div>
          <div class="mention-meta">${m.platform} • ${m.time} • ${m.likes} likes • Sentiment: ${m.sentiment.toFixed(2)}</div>
        </div>`
      ).join('');
    } else {
      latestMentions.innerHTML = 'No mentions yet';
    }
    
    // Media type chart
    const mediaCtx = document.getElementById('mediaTypeChart').getContext('2d');
    const mediaLabels = Object.keys(payload.media_types || {});
    const mediaData = Object.values(payload.media_types || {});
    if (mediaTypeChart) mediaTypeChart.destroy();
    mediaTypeChart = new Chart(mediaCtx, {type:'bar',data:{labels:mediaLabels,datasets:[{label:'Mentions',data:mediaData,backgroundColor:'rgba(245,158,11,0.8)',borderColor:'#f59e0b',borderWidth:2,borderRadius:8}]}, options:{responsive:true,maintainAspectRatio:true,plugins:{legend:{labels:{color:'#f1f5f9',font:{size:14,weight:'bold'}}}},scales:{x:{ticks:{color:'#cbd5e1'}},y:{ticks:{color:'#cbd5e1'}}}}});
    
    // Countries chart
    const countriesCtx = document.getElementById('countriesChart').getContext('2d');
    const countryLabels = Object.keys(payload.countries || {});
    const countryData = Object.values(payload.countries || {});
    if (countriesChart) countriesChart.destroy();
    countriesChart = new Chart(countriesCtx, {type:'bar',data:{labels:countryLabels,datasets:[{label:'Mentions',data:countryData,backgroundColor:'rgba(6,182,212,0.8)',borderColor:'#06b6d4',borderWidth:2,borderRadius:8}]}, options:{responsive:true,maintainAspectRatio:true,indexAxis:'y',plugins:{legend:{labels:{color:'#f1f5f9',font:{size:14,weight:'bold'}}}},scales:{x:{ticks:{color:'#cbd5e1'}},y:{ticks:{color:'#cbd5e1'}}}}});
    
    // Languages chart
    const langCtx = document.getElementById('languagesChart').getContext('2d');
    const langLabels = Object.keys(payload.languages || {});
    const langData = Object.values(payload.languages || {});
    if (languagesChart) languagesChart.destroy();
    languagesChart = new Chart(langCtx, {type:'doughnut',data:{labels:langLabels,datasets:[{data:langData,backgroundColor:['rgba(245,158,11,0.9)','rgba(6,182,212,0.9)','rgba(168,85,247,0.9)'],borderColor:'#1e293b',borderWidth:4}]}, options:{responsive:true,maintainAspectRatio:true,plugins:{legend:{labels:{color:'#f1f5f9',font:{size:14,weight:'bold'}}}}}});
    
    const alerts = document.getElementById('alertsList');
    alerts.innerHTML = (payload.alerts||[]).map(a=>`<div>[${a.time}] ${a.text}</div>`).join('') || 'No alerts';
    
    // Show generate caption button when we have data
    const generateCaptionBtn = document.getElementById('generateCaptionBtn');
    if (generateCaptionBtn) {
      generateCaptionBtn.style.display = payload.total_mentions > 0 ? 'inline-block' : 'none';
    }
  }, 300);
}

// Show loading skeletons
function showLoadingSkeletons() {
  // Metrics
  document.getElementById('m-count').innerHTML = '<div class="skeleton"></div>';
  document.getElementById('m-reach').innerHTML = '<div class="skeleton"></div>';
  document.getElementById('m-interactions').innerHTML = '<div class="skeleton"></div>';
  document.getElementById('m-sentiment').innerHTML = '<div class="skeleton"></div>';
  
  // Best time
  document.getElementById('bestTime').innerHTML = '<div class="skeleton" style="width: 60%; height: 20px;"></div>';
  
  // Related list
  const related = document.getElementById('relatedList');
  related.innerHTML = '';
  for (let i = 0; i < 5; i++) {
    const li = document.createElement('li');
    li.innerHTML = '<div class="skeleton" style="width: 80%; height: 16px;"></div>';
    related.appendChild(li);
  }
}

// Animate numeric values
function animateValue(element, start, end, duration) {
  if (!element) return;
  
  const range = end - start;
  const increment = end > start ? 1 : -1;
  const stepTime = Math.abs(Math.floor(duration / range));
  const startTime = new Date().getTime();
  
  const timer = setInterval(() => {
    const now = new Date().getTime();
    const elapsed = now - startTime;
    const progress = Math.min(elapsed / duration, 1);
    const value = Math.floor(progress * range + start);
    
    element.innerText = value.toLocaleString();
    
    if (progress === 1) {
      clearInterval(timer);
      element.innerText = end.toLocaleString();
    }
  }, stepTime);
}

function renderTrendChart(historicalData, forecastData) {
  const ctx = document.getElementById('trendChart').getContext('2d');
  
  // Destroy existing chart if it exists
  if (currentTrendChart) {
    currentTrendChart.destroy();
  }
  
  // Prepare historical data
  const historicalLabels = historicalData.map(d => d.date);
  const historicalValues = historicalData.map(d => d.count);
  
  // Prepare datasets
  const datasets = [{
    label: 'Historical Mentions',
    data: historicalValues,
    borderColor: '#00F2FF',
    backgroundColor: 'rgba(0, 242, 255, 0.1)',
    borderWidth: 3,
    fill: true,
    tension: 0.4
  }];
  
  // Add forecast data if available
  if (forecastData && forecastData.length > 0) {
    const forecastLabels = forecastData.map(d => d.date);
    const forecastValues = forecastData.map(d => d.count);
    
    // Combine labels (remove duplicates)
    const allLabels = [...historicalLabels];
    forecastLabels.forEach(label => {
      if (!allLabels.includes(label)) {
        allLabels.push(label);
      }
    });
    
    // Create combined dataset
    datasets.push({
      label: 'Forecast',
      data: [...historicalValues, ...forecastValues],
      borderColor: '#7B61FF',
      borderWidth: 2,
      borderDash: [5, 5],
      pointRadius: forecastValues.map((_, i) => i < historicalValues.length ? 0 : 3),
      tension: 0.4
    });
  }
  
  // Get the canvas element to set explicit dimensions
  const canvas = document.getElementById('trendChart');
  canvas.width = canvas.parentElement.clientWidth;
  canvas.height = 300;
  
  currentTrendChart = new Chart(ctx, {
    type: 'line',
    data: {
      labels: historicalLabels,
      datasets: datasets
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      aspectRatio: 2,
      plugins: {
        legend: {
          labels: {
            color: '#E8EAF6',
            font: {
              size: 12
            }
          }
        }
      },
      scales: {
        x: {
          grid: {
            color: 'rgba(255, 255, 255, 0.1)'
          },
          ticks: {
            color: '#A0A7D6',
            maxRotation: 45,
            minRotation: 45
          }
        },
        y: {
          grid: {
            color: 'rgba(255, 255, 255, 0.1)'
          },
          ticks: {
            color: '#A0A7D6'
          }
        }
      }
    }
  });
}

// Function to generate and display caption
function generateCaption(hashtag) {
  fetch('/api/caption/generate', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({ hashtag: hashtag })
  })
  .then(response => response.json())
  .then(data => {
    if (data.caption) {
      // Show caption in a modal or alert
      showCaptionModal(data.caption, data.character_count);
    } else if (data.error) {
      alert('Error generating caption: ' + data.error);
    }
  })
  .catch(error => {
    console.error('Error generating caption:', error);
    alert('Error generating caption. Please try again.');
  });
}

// Function to show caption in a modal
function showCaptionModal(caption, characterCount) {
  // Create modal HTML
  const modalHTML = `
    <div class="modal-overlay" id="captionModal">
      <div class="modal">
        <div class="modal-header">
          <h3>Generated Caption</h3>
          <button class="modal-close" id="closeModal">&times;</button>
        </div>
        <div class="modal-body">
          <textarea id="captionText" readonly>${caption}</textarea>
          <div class="caption-stats">
            <span>Characters: ${characterCount}</span>
            <button id="copyCaptionBtn" class="btn">Copy to Clipboard</button>
          </div>
        </div>
      </div>
    </div>
  `;
  
  // Add modal to body
  document.body.insertAdjacentHTML('beforeend', modalHTML);
  
  // Add event listeners
  document.getElementById('closeModal').addEventListener('click', function() {
    document.getElementById('captionModal').remove();
  });
  
  document.getElementById('copyCaptionBtn').addEventListener('click', function() {
    const captionText = document.getElementById('captionText');
    captionText.select();
    document.execCommand('copy');
    
    // Show feedback
    const copyBtn = document.getElementById('copyCaptionBtn');
    const originalText = copyBtn.textContent;
    copyBtn.textContent = 'Copied!';
    setTimeout(() => {
      copyBtn.textContent = originalText;
    }, 2000);
  });
  
  // Close modal when clicking outside
  document.querySelector('.modal-overlay').addEventListener('click', function(e) {
    if (e.target === this) {
      this.remove();
    }
  });
}

// cooccurrence rendering
document.getElementById('coocc') && fetch('/api/cooccurrence').then(r=>r.json()).then(data=>{
  const el = document.getElementById('coocc');
  el.innerHTML = '';
  const width = el.clientWidth || 800, height = el.clientHeight || 420;
  const svg = d3.select(el).append('svg').attr('width',width).attr('height',height);
  const links = data.links || []; const nodes = data.nodes || [];
  
  // Create a zoom behavior
  const zoom = d3.zoom()
    .scaleExtent([0.1, 8])
    .on('zoom', (event) => {
      svg.selectAll('g').attr('transform', event.transform);
    });
  
  // Add zoom functionality to the SVG
  svg.call(zoom);
  
  // Create groups for links, nodes, and labels
  const linkGroup = svg.append('g').attr('class', 'links');
  const nodeGroup = svg.append('g').attr('class', 'nodes');
  const labelGroup = svg.append('g').attr('class', 'labels');
  
  // Draw links with varying thickness based on value
  const link = linkGroup.selectAll('line')
    .data(links)
    .enter()
    .append('line')
    .attr('stroke', 'rgba(255,255,255,0.2)')
    .attr('stroke-width', d => Math.sqrt(d.value) * 2)
    .attr('stroke-opacity', 0.6);
  
  // Draw nodes with size based on importance
  const node = nodeGroup.selectAll('circle')
    .data(nodes)
    .enter()
    .append('circle')
    .attr('r', 8)
    .attr('fill', '#00f0ff')
    .attr('stroke', '#fff')
    .attr('stroke-width', 1.5)
    .call(d3.drag()
      .on('start', dragstarted)
      .on('drag', dragged)
      .on('end', dragended));
  
  // Draw labels with better positioning
  const label = labelGroup.selectAll('text')
    .data(nodes)
    .enter()
    .append('text')
    .text(d => d.id)
    .attr('font-size', 12)
    .attr('dx', 12)
    .attr('dy', 4)
    .attr('fill', '#ffffff')
    .attr('font-weight', 'bold')
    .attr('text-shadow', '1px 1px 2px black');
  
  // Add hover effects
  node.on('mouseover', function(event, d) {
    d3.select(this).attr('r', 12).attr('fill', '#ff00ff');
    label.filter(l => l.id === d.id).attr('font-size', 14).attr('fill', '#ff00ff');
  }).on('mouseout', function(event, d) {
    d3.select(this).attr('r', 8).attr('fill', '#00f0ff');
    label.filter(l => l.id === d.id).attr('font-size', 12).attr('fill', '#ffffff');
  });
  
  // Create force simulation with improved physics
  const simulation = d3.forceSimulation(nodes)
    .force('link', d3.forceLink(links).id(d => d.id).distance(100).strength(0.5))
    .force('charge', d3.forceManyBody().strength(-300))
    .force('center', d3.forceCenter(width / 2, height / 2))
    .force('collision', d3.forceCollide().radius(20));
  
  // Update positions on each tick
  simulation.on('tick', () => {
    link
      .attr('x1', d => d.source.x)
      .attr('y1', d => d.source.y)
      .attr('x2', d => d.target.x)
      .attr('y2', d => d.target.y);
    
    node
      .attr('cx', d => d.x)
      .attr('cy', d => d.y);
    
    label
      .attr('x', d => d.x)
      .attr('y', d => d.y);
  });
  
  // Drag functions
  function dragstarted(event, d) {
    if (!event.active) simulation.alphaTarget(0.3).restart();
    d.fx = d.x;
    d.fy = d.y;
  }
  
  function dragged(event, d) {
    d.fx = event.x;
    d.fy = event.y;
  }
  
  function dragended(event, d) {
    if (!event.active) simulation.alphaTarget(0);
    d.fx = null;
    d.fy = null;
  }
}).catch(()=>{});