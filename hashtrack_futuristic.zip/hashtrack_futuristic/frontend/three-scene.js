/* THREE.js animated 3D hashtag model for HashTrack (neon glow) */
let scene, camera, renderer, controls, hashtagMesh, glowMesh, particleSystem;
const container = document.getElementById('threeContainer');

function initThree(){
  scene = new THREE.Scene();
  scene.fog = new THREE.FogExp2(0x050B1E, 0.15);
  
  // Initialize with container dimensions
  let width = container.clientWidth || 480;
  let height = container.clientHeight || 320;
  
  // Ensure minimum dimensions
  width = Math.max(width, 300);
  height = Math.max(height, 300);
  
  camera = new THREE.PerspectiveCamera(50, width / height, 0.1, 1000);
  camera.position.set(0, 0.6, 2.6);

  renderer = new THREE.WebGLRenderer({ antialias:true, alpha:true });
  renderer.setSize(width, height);
  renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
  renderer.setClearColor(0x050B1E, 1);
  container.appendChild(renderer.domElement);

  controls = new THREE.OrbitControls(camera, renderer.domElement);
  controls.enablePan = false;
  controls.enableZoom = true;
  controls.autoRotate = true;
  controls.autoRotateSpeed = 0.6;

  // lighting
  const amb = new THREE.AmbientLight(0x00F2FF, 0.3);
  scene.add(amb);
  
  const p1 = new THREE.PointLight(0x00F2FF, 1.5, 10);
  p1.position.set(2, 2, 2);
  scene.add(p1);
  
  const p2 = new THREE.PointLight(0x7B61FF, 1.2, 10);
  p2.position.set(-2, -1, 1);
  scene.add(p2);
  
  const p3 = new THREE.PointLight(0xFF2D75, 0.8, 8);
  p3.position.set(0, 2, -2);
  scene.add(p3);

  // create hashtag shape using TextGeometry-like construct (use box geometries to build #)
  const g = new THREE.Group();
  // Cyberpunk neon materials
  const mat = new THREE.MeshStandardMaterial({ 
    color: 0x00F2FF, 
    emissive: 0x007F9A, 
    metalness: 0.7, 
    roughness: 0.1,
    transparent: true,
    opacity: 0.9
  });
  
  const mat2 = new THREE.MeshStandardMaterial({ 
    color: 0x7B61FF, 
    emissive: 0x332255, 
    metalness: 0.7, 
    roughness: 0.1,
    transparent: true,
    opacity: 0.9
  });

  function bar(w,h,depth){
    return new THREE.Mesh(new THREE.BoxGeometry(w,h,depth), mat);
  }
  // build hash sign (#) with four bars
  const bar1 = bar(0.12,0.9,0.12); bar1.position.set(-0.16,0,0);
  const bar2 = bar(0.12,0.9,0.12); bar2.position.set(0.16,0,0);
  const bar3 = new THREE.Mesh(new THREE.BoxGeometry(0.9,0.12,0.12), mat2); bar3.position.set(0,0.18,0);
  const bar4 = new THREE.Mesh(new THREE.BoxGeometry(0.9,0.12,0.12), mat2); bar4.position.set(0,-0.18,0);
  g.add(bar1,bar2,bar3,bar4);
  hashtagMesh = g;
  scene.add(hashtagMesh);

  // subtle glow: duplicate geometry scaled with additive blending
  const glowMat = new THREE.MeshBasicMaterial({ 
    color: 0x00F2FF, 
    transparent: true, 
    opacity: 0.2, 
    blending: THREE.AdditiveBlending 
  });
  glowMesh = hashtagMesh.clone();
  glowMesh.traverse(c => { if (c.isMesh) c.material = glowMat; });
  glowMesh.scale.set(1.6, 1.6, 1.6);
  scene.add(glowMesh);

  // Add floating particles for cyberpunk effect
  createParticles();

  // floor
  const floor = new THREE.Mesh(
    new THREE.PlaneGeometry(6, 6), 
    new THREE.MeshStandardMaterial({ 
      color: 0x050B1E, 
      roughness: 0.8,
      metalness: 0.2
    })
  );
  floor.rotation.x = -Math.PI/2; 
  floor.position.y = -1.1; 
  scene.add(floor);

  window.addEventListener('resize', onResize);
  
  // Initial resize to ensure proper sizing
  setTimeout(onResize, 100);
  
  animate();
}

function createParticles() {
  const particleCount = 1000;
  const particles = new THREE.BufferGeometry();
  const posArray = new Float32Array(particleCount * 3);
  
  for (let i = 0; i < particleCount * 3; i++) {
    posArray[i] = (Math.random() - 0.5) * 20;
  }
  
  particles.setAttribute('position', new THREE.BufferAttribute(posArray, 3));
  
  const particleMaterial = new THREE.PointsMaterial({
    color: 0x00F2FF,
    size: 0.02,
    transparent: true,
    blending: THREE.AdditiveBlending
  });
  
  particleSystem = new THREE.Points(particles, particleMaterial);
  scene.add(particleSystem);
}

function onResize(){
  // Ensure container has dimensions
  const w = Math.max(container.clientWidth || 480, 300);
  const h = Math.max(container.clientHeight || 320, 300);
  
  camera.aspect = w/h; 
  camera.updateProjectionMatrix(); 
  renderer.setSize(w, h);
}

let t = 0;
function animate(){
  requestAnimationFrame(animate);
  t += 0.01;
  
  // Animate hashtag
  hashtagMesh.rotation.y = 0.25 * Math.sin(t*0.8);
  hashtagMesh.rotation.x = 0.06 * Math.sin(t*0.6);
  hashtagMesh.position.y = 0.05 * Math.sin(t*0.5);
  
  // Animate glow
  glowMesh.rotation.copy(hashtagMesh.rotation);
  glowMesh.position.copy(hashtagMesh.position);
  
  // Animate particles
  if (particleSystem) {
    const positions = particleSystem.geometry.attributes.position.array;
    for (let i = 0; i < positions.length; i += 3) {
      positions[i + 1] -= 0.01;
      if (positions[i + 1] < -10) {
        positions[i + 1] = 10;
      }
    }
    particleSystem.geometry.attributes.position.needsUpdate = true;
  }
  
  controls.update();
  renderer.render(scene, camera);
}

initThree();