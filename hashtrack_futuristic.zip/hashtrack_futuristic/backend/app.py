#!/usr/bin/env python3
import os, json, subprocess
from flask import Flask, request, jsonify, send_from_directory, send_file
from flask_cors import CORS
from datetime import datetime, timedelta
import pandas as pd

DATA_PATH = os.getenv('HASHTRACK_DATA_PATH', os.path.join(os.path.dirname(__file__), '..', 'social_media_hashtag_trends_3000_rows.csv'))
SPARK_SUBMIT_CMD = os.getenv('SPARK_SUBMIT_CMD', r'C:\spark\spark-4.0.1-bin-hadoop3\spark-4.0.1-bin-hadoop3\bin\spark-submit.cmd' if os.name == 'nt' else 'spark-submit')
SPARK_DIR = os.path.join(os.path.dirname(__file__), '..', 'spark')
OUTPUT_DIR = os.path.join(os.path.dirname(__file__), '..', 'output')
os.makedirs(OUTPUT_DIR, exist_ok=True)

app = Flask(__name__, static_folder='../frontend', static_url_path='/')
CORS(app)

print('HashTrack backend starting. DATA_PATH=', DATA_PATH)
if os.path.exists(DATA_PATH):
    try:
        df = pd.read_csv(DATA_PATH, parse_dates=['post_time'], low_memory=False)
        df['hashtag_norm'] = df['hashtag'].astype(str).str.lstrip('#').str.lower()
        df['date'] = pd.to_datetime(df['post_time']).dt.date
        print('Loaded dataset rows=', len(df))
    except Exception as e:
        print('Failed loading dataset:', e)
        df = pd.DataFrame()
else:
    print('Dataset not found at', DATA_PATH)
    df = pd.DataFrame()

@app.route('/')
def index():
    return send_from_directory('../frontend', 'index.html')

@app.route('/<path:path>')
def static_proxy(path):
    return send_from_directory('../frontend', path)

@app.route('/api/meta')
def meta():
    if df.empty:
        return jsonify({'platforms': [], 'countries': []})
    return jsonify({'platforms': sorted(df['platform'].dropna().unique().tolist()), 'countries': sorted(df['country'].dropna().unique().tolist())})

@app.route('/api/track')
def track():
    tag = request.args.get('tag','').lstrip('#').lower()
    if not tag:
        return jsonify({'error':'tag missing'}), 400
    if df.empty:
        return jsonify({'error':'dataset not loaded'}), 500
    dff = df[df['hashtag_norm'].str.contains(tag, na=False)]
    daily = dff.groupby('date').size().reset_index(name='count').sort_values('date') if not dff.empty else pd.DataFrame()
    timeseries = [{'date': str(r['date']), 'count': int(r['count'])} for _, r in daily.iterrows()] if not daily.empty else []
    
    # Calculate interactions
    interactions = int(dff['likes'].sum() + dff['comments'].sum() + dff['shares'].sum()) if not dff.empty else 0
    
    # Sentiment breakdown
    positive_mentions = int((dff['sentiment_score'] > 0.5).sum()) if not dff.empty else 0
    negative_mentions = int((dff['sentiment_score'] < -0.5).sum()) if not dff.empty else 0
    neutral_mentions = int(dff.shape[0]) - positive_mentions - negative_mentions if not dff.empty else 0
    
    # Sentiment over time
    sentiment_timeseries = []
    if not dff.empty:
        sentiment_daily = dff.groupby('date')['sentiment_score'].mean().reset_index().sort_values('date')
        sentiment_timeseries = [{'date': str(r['date']), 'sentiment': float(r['sentiment_score'])} for _, r in sentiment_daily.iterrows()]
    
    # Media type breakdown
    media_types = dff['platform'].value_counts().head(5).to_dict() if not dff.empty else {}
    
    # Country breakdown
    countries = dff['country'].value_counts().head(10).to_dict() if not dff.empty else {}
    
    # Best time to post (day of week and hour)
    best_time = {'day': 'Wednesday', 'hour': '6 AM'}
    if not dff.empty:
        dff_time = dff.copy()
        dff_time['hour'] = pd.to_datetime(dff_time['post_time']).dt.hour
        dff_time['day'] = pd.to_datetime(dff_time['post_time']).dt.day_name()
        hour_counts = dff_time['hour'].value_counts()
        day_counts = dff_time['day'].value_counts()
        if not hour_counts.empty:
            best_hour = hour_counts.idxmax()
            best_time['hour'] = f"{best_hour % 12 or 12} {'AM' if best_hour < 12 else 'PM'}"
        if not day_counts.empty:
            best_time['day'] = day_counts.idxmax()
    
    # Languages
    languages = {'English': 85, 'Spanish': 10, 'Other': 5}  # Placeholder
    
    # Latest mentions
    latest_mentions = []
    if not dff.empty:
        latest = dff.nlargest(5, 'post_time')[['text', 'post_time', 'platform', 'likes', 'sentiment_score']]
        latest_mentions = [{
            'text': str(r['text'])[:100],
            'time': str(r['post_time']),
            'platform': str(r['platform']),
            'likes': int(r['likes']),
            'sentiment': float(r['sentiment_score'])
        } for _, r in latest.iterrows()]
    
    payload = {
        'hashtag': tag,
        'total_mentions': int(dff.shape[0]) if not dff.empty else 0,
        'estimated_reach': int(dff['reach'].sum()) if 'reach' in dff.columns else 0,
        'interactions': interactions,
        'shares': int(dff['shares'].sum()) if 'shares' in dff.columns else 0,
        'sentiment': float(dff['sentiment_score'].mean()) if 'sentiment_score' in dff.columns else 0.0,
        'positive_mentions': positive_mentions,
        'negative_mentions': negative_mentions,
        'neutral_mentions': neutral_mentions,
        'timeseries': timeseries or _zero_series(),
        'sentiment_timeseries': sentiment_timeseries,
        'related': dff['hashtag'].value_counts().head(10).index.tolist() if not dff.empty else [],
        'media_types': media_types,
        'countries': countries,
        'best_time': best_time,
        'languages': languages,
        'latest_mentions': latest_mentions,
        'alerts': _alerts_from_timeseries(timeseries)
    }
    return jsonify(payload)

def _zero_series(days=21):
    today = datetime.utcnow().date()
    return [{'date': (today - timedelta(days=(days-1-i))).isoformat(), 'count': 0} for i in range(days)]

def _alerts_from_timeseries(ts):
    if len(ts) < 2: return []
    if ts[-1]['count'] > 1.5 * ts[-2]['count']:
        return [{'time': ts[-1]['date'], 'text': 'Spike detected (>50%) compared to previous day'}]
    return []

@app.route('/api/cooccurrence')
def cooccurrence():
    coocc_file = os.path.join(OUTPUT_DIR, 'cooccurrence', 'cooccurrence.json')
    if os.path.exists(coocc_file):
        try:
            with open(coocc_file) as fh:
                return jsonify(json.load(fh))
        except:
            pass
    
    # If no precomputed file exists, run Spark job to generate it
    import subprocess
    import shutil
    
    # Check if spark-submit exists
    spark_submit_found = shutil.which(SPARK_SUBMIT_CMD) or os.path.exists(SPARK_SUBMIT_CMD)
    if not spark_submit_found:
        # Return empty data if Spark is not available
        return jsonify({'nodes': [], 'links': []})
    
    # Run Spark job to generate co-occurrence data
    script = os.path.join(SPARK_DIR, "cooccurrence_spark.py")
    out = os.path.join(OUTPUT_DIR, "cooccurrence")
    os.makedirs(out, exist_ok=True)
    
    # Set environment variables for Spark
    env = os.environ.copy()
    env['PYSPARK_PYTHON'] = r'C:\Users\sarva\AppData\Local\Programs\Python\Python310\python.exe'
    env['JAVA_HOME'] = r'C:\Program Files\Eclipse Adoptium\jdk-17.0.17.10-hotspot'
    env['SPARK_HOME'] = r'C:\spark\spark-4.0.1-bin-hadoop3\spark-4.0.1-bin-hadoop3'
    env['HADOOP_HOME'] = r'C:\hadoop'
    env['HADOOP_CONF_DIR'] = r'C:\hadoop\conf'
    # Fix for Hadoop native IO issue on Windows
    env['HADOOP_OPTS'] = '-Djava.library.path="C:\hadoop\bin"'
    
    # Define the Spark command with configurations to disable native IO and optimize for speed
    cmd = [SPARK_SUBMIT_CMD, "--conf", "spark.hadoop.io.native.lib.available=false", "--conf", "spark.sql.adaptive.enabled=false", "--conf", "spark.hadoop.mapreduce.fileoutputcommitter.algorithm.version=2", "--conf", "spark.hadoop.dfs.client.use.datanode.hostname=false", "--conf", "spark.sql.shuffle.partitions=4", "--conf", "spark.default.parallelism=4", script, DATA_PATH, out]
    
    # Log the command and environment for debugging
    print(f"Executing Spark command: {' '.join(cmd)}")
    print(f"Environment variables: JAVA_HOME={env.get('JAVA_HOME')}, PYSPARK_PYTHON={env.get('PYSPARK_PYTHON')}, SPARK_HOME={env.get('SPARK_HOME')}, HADOOP_HOME={env.get('HADOOP_HOME')}")
    
    try:
        proc = subprocess.run(cmd, capture_output=True, text=True, check=False, timeout=600, env=env)
        print(f"Spark process completed with return code: {proc.returncode}")
        print(f"Spark stdout: {proc.stdout}")
        print(f"Spark stderr: {proc.stderr}")
        
        # Check if the co-occurrence file was created
        if os.path.exists(coocc_file):
            with open(coocc_file) as fh:
                return jsonify(json.load(fh))
        else:
            # Fallback to original method if Spark job failed
            pass
    except:
        # Fallback to original method if Spark job failed
        pass
    
    # Fallback method if Spark is not available or failed
    if df.empty:
        return jsonify({'nodes': [], 'links': []})
    
    top = df['hashtag'].value_counts().head(50)
    nodes = [{'id': h} for h in top.index.tolist()]
    links = []
    top_list = top.index.tolist()[:30]
    for i, h in enumerate(top_list):
        for j, h2 in enumerate(top_list):
            if i >= j: 
                continue
            cats_h = set(df[df['hashtag'] == h]['category'].dropna().unique().tolist())
            cats_h2 = set(df[df['hashtag'] == h2]['category'].dropna().unique().tolist())
            w = len(cats_h.intersection(cats_h2))
            if w > 0:
                links.append({'source': h, 'target': h2, 'value': w})
    
    return jsonify({'nodes': nodes, 'links': links})

@app.route('/api/run_spark', methods=['POST'])
def run_spark():
    payload = request.get_json() or {}
    job = payload.get('job')
    if job not in ('trending','cooccurrence','clusters','anomaly','smart_analysis'):
        return jsonify({'error':'unknown job'}), 400
    
    if job == 'clusters':
        script = os.path.join(SPARK_DIR, "cluster_hashtags_spark.py")
    elif job == 'smart_analysis':
        script = os.path.join(SPARK_DIR, "smart_analysis_spark_api.py")
    else:
        script = os.path.join(SPARK_DIR, f"{job}_spark.py")
    
    input_path = payload.get('input', DATA_PATH)
    out = payload.get('output', os.path.join(OUTPUT_DIR, job))
    os.makedirs(out, exist_ok=True)
    
    # Check if spark-submit exists
    import shutil
    spark_submit_found = shutil.which(SPARK_SUBMIT_CMD) or os.path.exists(SPARK_SUBMIT_CMD)
    
    if not spark_submit_found:
        # Try to provide helpful guidance
        error_msg = 'Apache Spark spark-submit command not found.'
        message = f'Please ensure:\n1. Apache Spark is installed\n2. SPARK_SUBMIT_CMD environment variable is set correctly (currently: {SPARK_SUBMIT_CMD})\n3. spark-submit is in your PATH or provide full path\n\nSee SPARK_SETUP.txt for installation instructions.'
        
        # Try common Spark locations on Windows
        common_paths = [
            'C:\\spark\\spark-4.0.1-bin-hadoop3\\bin\\spark-submit.cmd',
            'C:\\spark\\bin\\spark-submit.cmd',
            'C:\\Program Files\\spark\\bin\\spark-submit.cmd',
            'C:\\apache-spark\\bin\\spark-submit.cmd'
        ]
        
        for path in common_paths:
            if os.path.exists(path):
                message += f'\n\nFound Spark at: {path}\nTry setting SPARK_SUBMIT_CMD environment variable to this path.'
                break
        
        return jsonify({
            'error': error_msg,
            'message': message,
            'returncode': -1
        }), 400
    
    # Optimized Spark command with configurations for faster execution
    cmd = [SPARK_SUBMIT_CMD, "--conf", "spark.hadoop.io.native.lib.available=false", "--conf", "spark.sql.adaptive.enabled=false", "--conf", "spark.hadoop.mapreduce.fileoutputcommitter.algorithm.version=2", "--conf", "spark.hadoop.dfs.client.use.datanode.hostname=false", "--conf", "spark.sql.shuffle.partitions=4", "--conf", "spark.default.parallelism=4", script, input_path, out]
    # Set environment variables for Spark
    env = os.environ.copy()
    env['PYSPARK_PYTHON'] = r'C:\Users\sarva\AppData\Local\Programs\Python\Python310\python.exe'
    env['JAVA_HOME'] = r'C:\Program Files\Eclipse Adoptium\jdk-17.0.17.10-hotspot'
    env['SPARK_HOME'] = r'C:\spark\spark-4.0.1-bin-hadoop3\spark-4.0.1-bin-hadoop3'
    env['HADOOP_HOME'] = r'C:\hadoop'
    env['HADOOP_CONF_DIR'] = r'C:\hadoop\conf'
    # Fix for Hadoop native IO issue on Windows
    env['HADOOP_OPTS'] = '-Djava.library.path="C:\hadoop\bin"'
    
    # Log the command and environment for debugging
    print(f"Executing Spark command: {' '.join(cmd)}")
    print(f"Environment variables: JAVA_HOME={env.get('JAVA_HOME')}, PYSPARK_PYTHON={env.get('PYSPARK_PYTHON')}, SPARK_HOME={env.get('SPARK_HOME')}, HADOOP_HOME={env.get('HADOOP_HOME')}")
    
    try:
        proc = subprocess.run(cmd, capture_output=True, text=True, check=False, timeout=600, env=env)
        print(f"Spark process completed with return code: {proc.returncode}")
        print(f"Spark stdout: {proc.stdout}")
        print(f"Spark stderr: {proc.stderr}")
        files = [os.path.join(out,f) for f in os.listdir(out) if f.startswith('part-') or f.endswith('.json') or f.endswith('.csv')] if os.path.exists(out) else []
        
        # For smart_analysis, return the popular hashtags summary
        if job == 'smart_analysis':
            summary_file = os.path.join(out, 'popular_hashtags.json')
            if os.path.exists(summary_file):
                with open(summary_file) as f:
                    summary = json.load(f)
                # Try to extract the actual port from the stdout
                spark_ui_url = 'http://localhost:4042'  # Default
                for line in proc.stdout.split('\n'):
                    if 'Spark Web UI available at:' in line:
                        # Extract URL from line like "[INFO] Spark Web UI available at: http://localhost:4042"
                        import re
                        match = re.search(r'http://localhost:(\d+)', line)
                        if match:
                            spark_ui_url = f'http://localhost:{match.group(1)}'
                            break
                
                return jsonify({
                    'returncode': proc.returncode,
                    'stdout': proc.stdout,
                    'stderr': proc.stderr,
                    'files': files,
                    'summary': summary,
                    'spark_ui': spark_ui_url,
                    'spark_ui_note': 'The Spark Web UI was available during job execution. For real-time monitoring, run Spark jobs directly with spark-submit to keep the UI alive.'
                })
        
        # Try to extract the actual port from the stdout
        spark_ui_url = 'http://localhost:4042'  # Default
        for line in proc.stdout.split('\n'):
            if 'Spark Web UI available at:' in line:
                # Extract URL from line like "[INFO] Spark Web UI available at: http://localhost:4042"
                import re
                match = re.search(r'http://localhost:(\d+)', line)
                if match:
                    spark_ui_url = f'http://localhost:{match.group(1)}'
                    break
        
        return jsonify({
            'returncode': proc.returncode,
            'stdout': proc.stdout,
            'stderr': proc.stderr,
            'files': files,
            'spark_ui': spark_ui_url,
            'spark_ui_note': 'The Spark Web UI was available during job execution (typically for a short time after job completion). For real-time monitoring, run Spark jobs directly with spark-submit to keep the UI alive.'
        })
    except FileNotFoundError as e:
        return jsonify({
            'error': f'Spark command not found: {SPARK_SUBMIT_CMD}',
            'message': 'Please install Apache Spark and ensure spark-submit is in your PATH. See SPARK_SETUP.txt for installation instructions.',
            'returncode': -1
        }), 400
    except subprocess.TimeoutExpired:
        return jsonify({'error':'Spark job timed out (10 minutes limit)'}), 500
    except Exception as e:
        # Log the actual error for debugging
        import traceback
        print(f"Spark error: {str(e)}")
        print(traceback.format_exc())
        # Return detailed error information
        return jsonify({
            'error': str(e),
            'message': f'An unexpected error occurred: {str(e)}',
            'returncode': -1,
            'spark_submit_cmd': SPARK_SUBMIT_CMD,
            'script_path': script,
            'input_path': input_path,
            'output_path': out
        }), 500

# Add a new endpoint for downloading CSV files
@app.route('/api/download_csv/<job_type>')
def download_csv(job_type):
    if job_type not in ('smart_analysis',):
        return jsonify({'error': 'Invalid job type'}), 400
    
    csv_file = os.path.join(OUTPUT_DIR, job_type, 'popular_hashtags.csv')
    if not os.path.exists(csv_file):
        return jsonify({'error': 'CSV file not found. Please run the analysis first.'}), 404
    
    return send_file(csv_file, as_attachment=True, download_name=f'{job_type}_results.csv')

@app.route('/api/forecast/<hashtag>')
def get_forecast(hashtag):
    """Return LSTM forecast for a hashtag"""
    import os
    import json
    
    # Check if we have precomputed forecast results
    forecast_file = os.path.join(OUTPUT_DIR, 'forecast', 'forecast_results.json')
    if os.path.exists(forecast_file):
        try:
            with open(forecast_file, 'r') as f:
                all_forecasts = json.load(f)
                # Find forecast for requested hashtag
                for forecast in all_forecasts:
                    if forecast.get('hashtag', '').lower() == hashtag.lower():
                        return jsonify(forecast)
        except Exception as e:
            print(f"Error reading forecast file: {e}")
    
    # If no precomputed results, return empty forecast
    return jsonify({
        'hashtag': hashtag,
        'rmse': 0,
        'historical': [],
        'forecast': [],
        'model_accuracy': 0
    })

@app.route('/api/insights/<hashtag>')
def get_insights(hashtag):
    """Return AI-generated insights for a hashtag"""
    # This would typically call a more complex analysis
    # For now, returning mock insights
    insights = {
        'hashtag': hashtag,
        'virality_prediction': {
            'score': 78,
            'confidence': 'high',
            'timeframe': '48 hours'
        },
        'optimal_posting': {
            'day': 'Wednesday',
            'time': '2-4 PM EST',
            'engagement_boost': '34%'
        },
        'sentiment_shift': {
            'direction': 'negative',
            'change': '22%',
            'timeframe': '24 hours'
        },
        'audience_expansion': {
            'regions': ['Spain', 'Mexico'],
            'opportunity': 'high'
        }
    }
    return jsonify(insights)

@app.route('/api/bursts')
def get_bursts():
    """Return recent burst detection alerts"""
    import os
    import json
    from datetime import datetime, timedelta
    
    # Check if we have precomputed burst alerts
    bursts_file = os.path.join(OUTPUT_DIR, 'bursts', 'burst_alerts.json')
    if os.path.exists(bursts_file):
        try:
            with open(bursts_file, 'r') as f:
                bursts = json.load(f)
                # Filter for recent bursts (last 24 hours)
                recent_bursts = []
                now = datetime.utcnow()
                for burst in bursts:
                    try:
                        burst_time = datetime.fromisoformat(burst.get('start_time', '').replace('Z', '+00:00'))
                        if now - burst_time < timedelta(hours=24):
                            recent_bursts.append(burst)
                    except:
                        # If we can't parse the time, include it to be safe
                        recent_bursts.append(burst)
                return jsonify(recent_bursts)
        except Exception as e:
            print(f"Error reading bursts file: {e}")
    
    # If no precomputed results, return empty list
    return jsonify([])

@app.route('/api/caption/generate', methods=['POST'])
def generate_caption():
    """Generate social media caption for a hashtag"""
    import json
    import random
    
    try:
        payload = request.get_json() or {}
        hashtag = payload.get('hashtag', '').lstrip('#').lower()
        
        if not hashtag:
            return jsonify({'error': 'Hashtag is required'}), 400
        
        # Template-based caption generation
        templates = [
            f"Join the conversation! #{hashtag} is trending now. What's your take? 🚀",
            f"Can you feel the buzz? #{hashtag} is taking over social media! 🔥",
            f"Don't miss out! #{hashtag} is the talk of the town. Join in! 💬",
            f"What's all the hype about? #{hashtag} is everywhere! Check it out! 👀",
            f"Be part of the movement! #{hashtag} is changing the game. Share your thoughts! 💡",
            f"The future is here! #{hashtag} is shaping conversations worldwide. Get involved! 🌍",
            f"Stay ahead of the curve! #{hashtag} is the trend you need to know. Engage now! ⏱️",
            f"Your voice matters! #{hashtag} needs your perspective. Speak up! 🗣️",
            f"Experience the phenomenon! #{hashtag} is redefining social discourse. Participate! 🌟",
            f"Be in the know! #{hashtag} is the pulse of current trends. Feel the beat! 💓"
        ]
        
        # Select a random template
        caption = random.choice(templates)
        
        # Add some hashtag variations
        variations = [
            f"{caption}\n\n#{hashtag} #trending #socialmedia",
            f"{caption}\n\n#{hashtag} #viral #discuss",
            f"{caption}\n\n#{hashtag} #trendwatch #engage",
            f"{caption}\n\n#{hashtag} #nowtrending #joinus"
        ]
        
        final_caption = random.choice(variations)
        
        return jsonify({
            'hashtag': hashtag,
            'caption': final_caption,
            'character_count': len(final_caption)
        })
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/visualization_data')
def visualization_data():
    if df.empty:
        return jsonify({'error': 'dataset not loaded'}), 500
    
    # Get overall statistics
    total_hashtags = df['hashtag'].nunique()
    total_mentions = len(df)
    avg_engagement = (df['likes'] + df['comments'] + df['shares']).mean()
    total_platforms = df['platform'].nunique()
    
    # Get hashtag distribution by category
    hashtag_distribution = df['category'].value_counts().head(10).to_dict()
    
    # Get engagement by platform
    platform_engagement = df.groupby('platform').agg({
        'likes': 'sum',
        'comments': 'sum',
        'shares': 'sum'
    }).sum(axis=1).sort_values(ascending=False).head(10).to_dict()
    
    # Get sentiment distribution
    sentiment_distribution = {
        'positive': int(len(df[df['sentiment_score'] > 0.1])),
        'neutral': int(len(df[(df['sentiment_score'] >= -0.1) & (df['sentiment_score'] <= 0.1)])),
        'negative': int(len(df[df['sentiment_score'] < -0.1]))
    }
    
    # Get top hashtags
    top_hashtags = df['hashtag'].value_counts().head(20).to_dict()
    
    # Get time series data (last 30 days)
    df['date'] = pd.to_datetime(df['post_time']).dt.date
    time_series = df.groupby('date').size().tail(30).to_dict()
    
    # Get geographic distribution
    geographic_distribution = df['country'].value_counts().head(10).to_dict()
    
    # Get device distribution
    device_distribution = df['device'].value_counts().to_dict()
    
    # Get virality score distribution
    virality_bins = pd.cut(df['virality_score'], bins=5, labels=['Very Low', 'Low', 'Medium', 'High', 'Very High'])
    virality_distribution = virality_bins.value_counts().to_dict()
    
    # Generate co-occurrence network data
    # Get top hashtags for network visualization
    top_hashtags_for_network = df['hashtag'].value_counts().head(15)
    top_hastag_list = top_hashtags_for_network.index.tolist()
    
    # Create nodes for the network
    nodes = []
    groups = {}  # To assign different groups to different categories
    group_counter = 1
    
    for hashtag in top_hastag_list:
        category = df[df['hashtag'] == hashtag]['category'].iloc[0] if not df[df['hashtag'] == hashtag].empty else 'Other'
        if category not in groups:
            groups[category] = group_counter
            group_counter += 1
        
        # Calculate node size based on mention count
        mention_count = int(top_hashtags_for_network[hashtag])
        radius = float(max(5, min(20, mention_count / max(top_hashtags_for_network) * 20)))
        
        nodes.append({
            'id': str(hashtag),
            'group': int(groups[category]),
            'radius': radius,
            'mentions': mention_count
        })
    
    # Create links based on co-occurrence in posts
    links = []
    # Group by post_time to find hashtags that appear together
    grouped = df.groupby('post_time')
    
    for time, group in grouped:
        if len(group) > 1:  # Only consider posts with multiple hashtags
            hashtags_in_post = group['hashtag'].tolist()
            # Create links between all pairs of hashtags in the same post
            for i in range(len(hashtags_in_post)):
                for j in range(i+1, len(hashtags_in_post)):
                    hashtag1 = hashtags_in_post[i]
                    hashtag2 = hashtags_in_post[j]
                    
                    # Only include links between top hashtags
                    if hashtag1 in top_hastag_list and hashtag2 in top_hastag_list:
                        # Check if link already exists
                        existing_link = None
                        for link in links:
                            if (link['source'] == hashtag1 and link['target'] == hashtag2) or \
                               (link['source'] == hashtag2 and link['target'] == hashtag1):
                                existing_link = link
                                break
                        
                        if existing_link:
                            existing_link['value'] = int(existing_link['value'] + 1)
                        else:
                            links.append({
                                'source': str(hashtag1),
                                'target': str(hashtag2),
                                'value': 1
                            })
    
    # Limit to top 30 links by value
    links = sorted(links, key=lambda x: x['value'], reverse=True)[:30]
    
    # Convert any numpy types to native Python types for JSON serialization
    def convert_types(obj):
        if isinstance(obj, dict):
            return {key: convert_types(value) for key, value in obj.items()}
        elif isinstance(obj, list):
            return [convert_types(item) for item in obj]
        elif hasattr(obj, 'item'):  # numpy scalars
            return obj.item()
        else:
            return obj
    
    result = {
        'overview': {
            'total_hashtags': int(total_hashtags),
            'total_mentions': int(total_mentions),
            'avg_engagement': float(avg_engagement),
            'total_platforms': int(total_platforms)
        },
        'hashtag_distribution': convert_types(hashtag_distribution),
        'platform_engagement': convert_types(platform_engagement),
        'sentiment_distribution': convert_types(sentiment_distribution),
        'top_hashtags': convert_types(top_hashtags),
        'time_series': {str(k): int(v) for k, v in time_series.items()},
        'geographic_distribution': convert_types(geographic_distribution),
        'device_distribution': convert_types(device_distribution),
        'virality_distribution': convert_types(virality_distribution),
        'cooccurrence_network': {
            'nodes': convert_types(nodes),
            'links': convert_types(links)
        }
    }
    
    return jsonify(result)

if __name__ == '__main__':
    print('HashTrack API up on http://0.0.0.0:5000')
    app.run(host='0.0.0.0', port=5000, debug=True)