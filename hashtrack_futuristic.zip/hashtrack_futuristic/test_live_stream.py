import asyncio
import websockets
import json

async def test_live_stream():
    uri = "ws://localhost:6000"
    try:
        async with websockets.connect(uri) as websocket:
            print("Connected to WebSocket server")
            
            # Keep connection alive and listen for messages
            message_count = 0
            while message_count < 10:  # Listen for 10 messages
                try:
                    message = await asyncio.wait_for(websocket.recv(), timeout=5.0)
                    data = json.loads(message)
                    print(f"Received #{message_count + 1}: {data}")
                    message_count += 1
                    
                    # If this is the initial connection message, send a response
                    if isinstance(data, dict) and data.get("status") == "connected":
                        await websocket.send("ack")
                        print("Sent acknowledgment")
                except asyncio.TimeoutError:
                    print("No message received within timeout")
                    break
                except json.JSONDecodeError as e:
                    print(f"Failed to decode JSON: {e}")
                    print(f"Raw message: {message}")
                    
            print("Live stream test completed successfully")
    except Exception as e:
        print(f"WebSocket connection failed: {e}")
        import traceback
        traceback.print_exc()

# Run the test
if __name__ == "__main__":
    asyncio.run(test_live_stream())