#!/usr/bin/env python3
"""
Test script to verify that the Spark job fixes work
"""
import subprocess
import os
import sys
import json

def test_spark_jobs():
    # Get the project root directory
    project_root = os.path.dirname(os.path.abspath(__file__))
    
    # Define paths
    spark_dir = os.path.join(project_root, 'spark')
    data_path = os.path.join(project_root, 'social_media_hashtag_trends_3000_rows.csv')
    output_base = os.path.join(project_root, 'output')
    
    # Check if data file exists
    if not os.path.exists(data_path):
        print(f"❌ Data file not found: {data_path}")
        return False
    
    # Test jobs
    jobs = [
        {
            'name': 'trending',
            'script': os.path.join(spark_dir, 'trending_spark.py'),
            'output_file': 'trending_results.json'
        },
        {
            'name': 'cooccurrence',
            'script': os.path.join(spark_dir, 'cooccurrence_spark.py'),
            'output_file': 'cooccurrence.json'
        },
        {
            'name': 'clusters',
            'script': os.path.join(spark_dir, 'cluster_hashtags_spark.py'),
            'output_file': 'cluster_results.json'
        }
    ]
    
    # Spark submit command
    spark_submit_cmd = r'C:\spark\spark-4.0.1-bin-hadoop3\spark-4.0.1-bin-hadoop3\bin\spark-submit.cmd'
    
    # Check if spark-submit exists
    if not (os.path.exists(spark_submit_cmd) or subprocess.run(['where', 'spark-submit'], capture_output=True, shell=True).returncode == 0):
        print("❌ Apache Spark spark-submit command not found.")
        print("Please ensure Apache Spark is installed and spark-submit is in your PATH.")
        return False
    
    all_passed = True
    
    for job in jobs:
        print(f"\n🚀 Testing {job['name']} job...")
        
        # Create output directory
        output_dir = os.path.join(output_base, job['name'])
        os.makedirs(output_dir, exist_ok=True)
        
        # Build command
        cmd = [spark_submit_cmd, job['script'], data_path, output_dir]
        
        # Set environment variables
        env = os.environ.copy()
        env['PYSPARK_PYTHON'] = r'C:\Users\sarva\AppData\Local\Programs\Python\Python310\python.exe'
        env['JAVA_HOME'] = r'C:\Program Files\Eclipse Adoptium\jdk-17.0.17.10-hotspot'
        env['SPARK_HOME'] = r'C:\spark\spark-4.0.1-bin-hadoop3\spark-4.0.1-bin-hadoop3'
        env['HADOOP_HOME'] = r'C:\hadoop'
        env['HADOOP_CONF_DIR'] = r'C:\hadoop\conf'
        env['HADOOP_OPTS'] = '-Djava.library.path="C:\hadoop\bin"'
        
        try:
            # Run the Spark job
            print(f"Executing: {' '.join(cmd)}")
            result = subprocess.run(cmd, capture_output=True, text=True, env=env, timeout=300)
            
            print(f"Return code: {result.returncode}")
            if result.stdout:
                print("STDOUT:")
                print(result.stdout)
            if result.stderr:
                print("STDERR:")
                print(result.stderr)
            
            # Check if the job succeeded
            if result.returncode == 0:
                # Check if output file was created
                output_file = os.path.join(output_dir, job['output_file'])
                if os.path.exists(output_file):
                    # Try to parse the JSON
                    try:
                        with open(output_file, 'r') as f:
                            data = json.load(f)
                        print(f"✅ {job['name']} job completed successfully!")
                        print(f"   Output file: {output_file}")
                        print(f"   Data size: {len(str(data))} characters")
                    except Exception as e:
                        print(f"⚠️ {job['name']} job completed but output file is invalid: {e}")
                        all_passed = False
                else:
                    print(f"⚠️ {job['name']} job completed but output file not found: {output_file}")
                    all_passed = False
            else:
                print(f"❌ {job['name']} job failed!")
                all_passed = False
                
        except subprocess.TimeoutExpired:
            print(f"❌ {job['name']} job timed out!")
            all_passed = False
        except Exception as e:
            print(f"❌ {job['name']} job failed with exception: {e}")
            all_passed = False
    
    return all_passed

if __name__ == "__main__":
    print("Testing Spark job fixes...")
    success = test_spark_jobs()
    
    if success:
        print("\n🎉 All Spark jobs passed!")
        sys.exit(0)
    else:
        print("\n💥 Some Spark jobs failed!")
        sys.exit(1)