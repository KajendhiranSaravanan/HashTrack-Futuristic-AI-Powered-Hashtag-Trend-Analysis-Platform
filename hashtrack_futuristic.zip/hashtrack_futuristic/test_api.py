import requests
import json

# Test the meta endpoint
print("Testing /api/meta endpoint...")
response = requests.get("http://localhost:5000/api/meta")
print(f"Status Code: {response.status_code}")
print(f"Response: {response.json()}")

# Test the co-occurrence endpoint
print("\nTesting /api/cooccurrence endpoint...")
response = requests.get("http://localhost:5000/api/cooccurrence")
print(f"Status Code: {response.status_code}")
data = response.json()
print(f"Nodes count: {len(data.get('nodes', []))}")
print(f"Links count: {len(data.get('links', []))}")

# Test the run_spark endpoint
print("\nTesting /api/run_spark endpoint...")
payload = {"job": "trending"}
response = requests.post("http://localhost:5000/api/run_spark", json=payload)
print(f"Status Code: {response.status_code}")
if response.status_code == 200:
    data = response.json()
    print(f"Return code: {data.get('returncode')}")
    print(f"Files generated: {data.get('files', [])}")
else:
    print(f"Error: {response.text}")