#!/usr/bin/env python3
"""
Long running Spark job for demonstrating Web UI features
"""
import time
import subprocess
import sys
import os

def run_long_spark_job():
    # Get the project paths
    project_root = os.path.dirname(os.path.abspath(__file__))
    spark_script = os.path.join(project_root, 'spark', 'trending_spark.py')
    data_path = os.path.join(project_root, 'social_media_hashtag_trends_3000_rows.csv')
    output_path = os.path.join(project_root, 'output', 'long_running_test')
    
    # Create output directory
    os.makedirs(output_path, exist_ok=True)
    
    # Spark submit command
    spark_submit_cmd = r'C:\spark\spark-4.0.1-bin-hadoop3\spark-4.0.1-bin-hadoop3\bin\spark-submit.cmd'
    
    # Check if files exist
    if not os.path.exists(spark_script):
        print(f"❌ Spark script not found: {spark_script}")
        return False
        
    if not os.path.exists(data_path):
        print(f"❌ Data file not found: {data_path}")
        return False
    
    # Modify the trending script to run longer by adding artificial delays
    modified_script_path = os.path.join(project_root, 'spark', 'long_trending_spark.py')
    
    # Read the original script
    with open(spark_script, 'r') as f:
        original_content = f.read()
    
    # Add artificial delays to make the job run longer
    modified_content = original_content.replace(
        '# Write results to JSON file',
        '''# Add artificial delay to make job run longer
import time
print("Adding artificial delay to demonstrate Web UI...")
time.sleep(30)  # 30 second delay

# Write results to JSON file'''
    )
    
    # Write the modified script
    with open(modified_script_path, 'w') as f:
        f.write(modified_content)
    
    # Set environment variables
    env = os.environ.copy()
    env['PYSPARK_PYTHON'] = r'C:\Users\sarva\AppData\Local\Programs\Python\Python310\python.exe'
    env['JAVA_HOME'] = r'C:\Program Files\Eclipse Adoptium\jdk-17.0.17.10-hotspot'
    env['SPARK_HOME'] = r'C:\spark\spark-4.0.1-bin-hadoop3\spark-4.0.1-bin-hadoop3'
    env['HADOOP_HOME'] = r'C:\hadoop'
    
    # Build command with UI configuration
    cmd = [
        spark_submit_cmd,
        "--conf", "spark.ui.host=localhost",
        "--conf", "spark.driver.host=localhost",
        "--conf", "spark.driver.bindAddress=127.0.0.1",
        modified_script_path,
        data_path,
        output_path
    ]
    
    print("🚀 Starting long-running Spark job with Web UI on localhost...")
    print(f"📝 Script: {modified_script_path}")
    print(f"📂 Data: {data_path}")
    print(f"💾 Output: {output_path}")
    print(f"🌐 Web UI will be available at: http://localhost:4042")
    print("=" * 60)
    print("The job will run for approximately 30 seconds to demonstrate the Web UI")
    print("During this time, you can monitor jobs, stages, and storage in the Web UI")
    print("=" * 60)
    
    try:
        # Start the Spark job
        process = subprocess.Popen(
            cmd, 
            stdout=subprocess.PIPE, 
            stderr=subprocess.STDOUT, 
            text=True, 
            env=env,
            bufsize=1
        )
        
        print("📊 Spark job started! Check http://localhost:4042 for the Web UI")
        print("📝 Job output:")
        print("-" * 40)
        
        # Stream output in real-time
        while True:
            output = process.stdout.readline()
            if output == '' and process.poll() is not None:
                break
            if output:
                print(output.strip())
        
        # Get the return code
        return_code = process.poll()
        
        print("-" * 40)
        if return_code == 0:
            print("✅ Spark job completed successfully!")
        else:
            print(f"⚠️ Spark job finished with return code: {return_code}")
            
        print(f"🌐 Spark Web UI was available at: http://localhost:4042")
        print("You can still access the UI for a short time after job completion")
        
        # Clean up the modified script
        if os.path.exists(modified_script_path):
            os.remove(modified_script_path)
            
        return return_code == 0
        
    except Exception as e:
        print(f"❌ Error running Spark job: {e}")
        # Clean up the modified script
        if os.path.exists(modified_script_path):
            os.remove(modified_script_path)
        return False

if __name__ == "__main__":
    success = run_long_spark_job()
    sys.exit(0 if success else 1)