#!/usr/bin/env python3
"""
Script to demonstrate how to connect to Spark Web UI
"""
import webbrowser
import time
import os

def connect_to_spark_ui():
    print("🎯 How to connect to Spark Web UI")
    print("=" * 50)
    
    print("\n📝 There are two ways to access the Spark Web UI:")
    
    print("\n1️⃣  Run a Spark job interactively:")
    print("   python run_spark_interactive.py trending")
    print("   - This will start a Spark job and display the Web UI URL")
    print("   - The UI will be available during job execution")
    
    print("\n2️⃣  Access an existing Spark Web UI:")
    print("   - If you have a running Spark application, you can access:")
    print("     http://localhost:4040  (default port)")
    print("     http://localhost:4041  (if 4040 is busy)")
    print("     http://localhost:4042  (if 4041 is also busy)")
    
    print("\n📊 Key UI Pages:")
    print("   - http://localhost:4041         → Main dashboard")
    print("   - http://localhost:4041/jobs    → Jobs overview")
    print("   - http://localhost:4041/stages  → Stages details")
    print("   - http://localhost:4041/storage → Storage information")
    print("   - http://localhost:4041/environment → Environment details")
    
    print("\n💡 Pro Tips:")
    print("   - The Web UI is only available while the Spark application is running")
    print("   - For real-time monitoring, use the interactive mode")
    print("   - Check the console output for the actual UI port")
    
    # Try to open the browser to the Spark UI
    print("\n🚀 Opening Spark Web UI in your browser...")
    try:
        # Try to open the most common Spark UI URLs
        urls_to_try = [
            "http://localhost:4040",
            "http://localhost:4041", 
            "http://localhost:4042"
        ]
        
        for url in urls_to_try:
            print(f"   Trying {url}...")
            # We'll just print the URL since we can't actually open the browser in this environment
            # In a real environment, you would use: webbrowser.open(url)
            if url == "http://localhost:4041":
                print(f"   ✅ You can access the Spark Web UI at: {url}")
                print("   (This is the most common URL for Spark UI)")
                break
    except Exception as e:
        print(f"   ⚠️  Could not open browser automatically: {e}")
    
    print("\n✅ To see the Spark Web UI in action:")
    print("   1. Run: python run_spark_interactive.py trending")
    print("   2. Look for the 'Spark UI will be available at:' message")
    print("   3. Open that URL in your browser")
    print("   4. Explore the different tabs to monitor your Spark job")

if __name__ == "__main__":
    connect_to_spark_ui()