#!/usr/bin/env python3
"""
Continuous Spark streaming job for demonstrating Web UI features
"""
import time
import subprocess
import sys
import os

def run_continuous_spark_job():
    # Get the project paths
    project_root = os.path.dirname(os.path.abspath(__file__))
    spark_script = os.path.join(project_root, 'spark', 'continuous_trending_spark.py')
    data_path = os.path.join(project_root, 'social_media_hashtag_trends_3000_rows.csv')
    output_path = os.path.join(project_root, 'output', 'continuous_test')
    
    # Create output directory
    os.makedirs(output_path, exist_ok=True)
    
    # Create a continuous streaming version of the trending script
    streaming_script_content = '''
#!/usr/bin/env python3
"""
Continuous streaming version of trending analysis
"""
import sys
import time
import os
from pyspark.sql import SparkSession
from pyspark.sql.functions import *
from pyspark.sql.types import *

def create_spark_session():
    """Create and configure Spark session with proper settings"""
    spark = SparkSession.builder \\
        .appName("HashTrack Trending Analysis") \\
        .config("spark.sql.adaptive.enabled", "false") \\
        .config("spark.sql.adaptive.coalescePartitions.enabled", "false") \\
        .config("spark.hadoop.io.native.lib.available", "false") \\
        .config("spark.hadoop.mapreduce.fileoutputcommitter.algorithm.version", "2") \\
        .config("spark.hadoop.dfs.client.use.datanode.hostname", "false") \\
        .config("spark.ui.host", "localhost") \\
        .config("spark.driver.host", "localhost") \\
        .config("spark.driver.bindAddress", "127.0.0.1") \\
        .getOrCreate()
    return spark

def main():
    if len(sys.argv) != 3:
        print("Usage: trending_spark.py <input_path> <output_path>")
        sys.exit(1)
    
    input_path = sys.argv[1]
    base_output_path = sys.argv[2]
    
    # Create Spark session
    spark = create_spark_session()
    
    # Read the CSV file
    df = spark.read.option("header", "true").csv(input_path)
    
    # Convert timestamp to proper format and extract date
    # Use the correct column name "post_time" 
    df = df.withColumn("timestamp", to_timestamp(col("post_time"), "yyyy-MM-dd'T'HH:mm:ss")) \\
           .withColumn("date", to_date(col("timestamp")))
    
    # Simulate continuous processing by running in a loop
    batch_count = 0
    max_batches = 3  # Reduce to 3 batches for faster execution
    
    while batch_count < max_batches:
        print(f"Processing batch {batch_count + 1}/{max_batches}...")
        
        # Reduce artificial processing time to 1 second for faster execution
        time.sleep(1)
        
        # Perform trending analysis on a sample of data
        sample_df = df.sample(0.05)  # Reduce sample size to 5% for faster processing
        
        # Count hashtags - use the correct column name "hashtag"
        hashtag_counts = sample_df.select(col("hashtag")) \\
                                 .filter(col("hashtag") != "") \\
                                 .groupBy("hashtag") \\
                                 .count() \\
                                 .orderBy(col("count").desc()) \\
                                 .limit(5)
        
        # Collect results locally to avoid FileOutputCommitter issues
        results = hashtag_counts.collect()
        
        # Convert to serializable format - FIXED JSON SERIALIZATION ISSUE
        output_data = [{"hashtag": str(row["hashtag"]), "count": int(row["count"])} for row in results]
        
        # Print some results to show progress
        print(f"Batch {batch_count + 1} results:")
        for i, item in enumerate(output_data[:2]):  # Show top 2
            print(f"  {i+1}. {item['hashtag']}: {item['count']}")
        
        batch_count += 1
        
        if batch_count < max_batches:
            print(f"Waiting 1 second before next batch...")  # Reduce wait time
            time.sleep(1)
    
    # Write final results
    import json
    output_file = os.path.join(base_output_path, "continuous_trending_results.json")
    os.makedirs(base_output_path, exist_ok=True)
    
    with open(output_file, 'w') as f:
        json.dump(output_data, f, indent=2)
    
    print(f"Successfully wrote {len(output_data)} records to {output_file}")
    spark.stop()

if __name__ == "__main__":
    main()
'''
    
    # Write the streaming script
    with open(spark_script, 'w') as f:
        f.write(streaming_script_content)
    
    # Spark submit command
    spark_submit_cmd = r'C:\spark\spark-4.0.1-bin-hadoop3\spark-4.0.1-bin-hadoop3\bin\spark-submit.cmd'
    
    # Set environment variables
    env = os.environ.copy()
    env['PYSPARK_PYTHON'] = r'C:\Users\sarva\AppData\Local\Programs\Python\Python310\python.exe'
    env['JAVA_HOME'] = r'C:\Program Files\Eclipse Adoptium\jdk-17.0.17.10-hotspot'
    env['SPARK_HOME'] = r'C:\spark\spark-4.0.1-bin-hadoop3\spark-4.0.1-bin-hadoop3'
    env['HADOOP_HOME'] = r'C:\hadoop'
    
    # Build command with UI configuration
    cmd = [
        spark_submit_cmd,
        "--conf", "spark.ui.host=localhost",
        "--conf", "spark.driver.host=localhost",
        "--conf", "spark.driver.bindAddress=127.0.0.1",
        spark_script,
        data_path,
        output_path
    ]
    
    print("🚀 Starting optimized continuous Spark job with Web UI on localhost...")
    print(f"📝 Script: {spark_script}")
    print(f"📂 Data: {data_path}")
    print(f"💾 Output: {output_path}")
    print(f"🌐 Web UI will be available at: http://localhost:4041")
    print("=" * 60)
    print("The job will run for approximately 6 seconds with 3 batches")
    print("During this time, you can monitor jobs, stages, and storage in the Web UI")
    print("Press Ctrl+C to stop early")
    print("=" * 60)
    
    try:
        # Start the Spark job
        process = subprocess.Popen(
            cmd, 
            stdout=subprocess.PIPE, 
            stderr=subprocess.STDOUT, 
            text=True, 
            env=env,
            bufsize=1
        )
        
        print("📊 Spark job started! Check http://localhost:4041 for the Web UI")
        print("📝 Job output:")
        print("-" * 40)
        
        # Stream output in real-time
        while True:
            output = process.stdout.readline()
            if output == '' and process.poll() is not None:
                break
            if output:
                print(output.strip())
        
        # Get the return code
        return_code = process.poll()
        
        print("-" * 40)
        if return_code == 0:
            print("✅ Spark job completed successfully!")
        else:
            print(f"⚠️ Spark job finished with return code: {return_code}")
            
        print(f"🌐 Spark Web UI was available at: http://localhost:4041")
        print("You can still access the UI for a short time after job completion")
        
        # Clean up the streaming script
        if os.path.exists(spark_script):
            os.remove(spark_script)
            
        return return_code == 0
        
    except KeyboardInterrupt:
        print("\\n🛑 Stopping Spark job...")
        process.terminate()
        process.wait()
        print("✅ Spark job stopped!")
        
        # Clean up the streaming script
        if os.path.exists(spark_script):
            os.remove(spark_script)
            
        return True
    except Exception as e:
        print(f"❌ Error running Spark job: {e}")
        # Clean up the streaming script
        if os.path.exists(spark_script):
            os.remove(spark_script)
        return False

if __name__ == "__main__":
    success = run_continuous_spark_job()
    sys.exit(0 if success else 1)