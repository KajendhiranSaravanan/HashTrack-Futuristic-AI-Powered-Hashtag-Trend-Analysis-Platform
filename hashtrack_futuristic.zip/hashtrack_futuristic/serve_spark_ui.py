HTML_CONTENT = '''<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Spark Web UI - HashTrack Analysis</title>
    <style>
        :root {
            --bg-dark: #050B1E;
            --primary-neon: #00F2FF;
            --secondary-neon: #7B61FF;
            --trend-highlight: #FF2D75;
            --text-main: #E8EAF6;
            --card-bg: rgba(255, 255, 255, 0.08);
        }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: var(--bg-dark);
            color: var(--text-main);
            margin: 0;
            padding: 0;
        }
        
        header {
            background: linear-gradient(90deg, var(--primary-neon), var(--secondary-neon));
            padding: 15px 20px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.3);
        }
        
        .header-content {
            display: flex;
            justify-content: space-between;
            align-items: center;
            max-width: 1200px;
            margin: 0 auto;
        }
        
        h1 {
            margin: 0;
            font-size: 24px;
            color: var(--bg-dark);
            font-weight: 700;
        }
        
        .nav-tabs {
            display: flex;
            background-color: rgba(0, 0, 0, 0.2);
            border-radius: 8px;
            padding: 5px;
        }
        
        .nav-tab {
            padding: 10px 20px;
            text-decoration: none;
            color: var(--text-main);
            border-radius: 5px;
            margin: 0 5px;
            transition: all 0.3s ease;
        }
        
        .nav-tab.active {
            background-color: var(--primary-neon);
            color: var(--bg-dark);
            font-weight: bold;
        }
        
        .container {
            max-width: 1200px;
            margin: 20px auto;
            padding: 0 20px;
        }
        
        .summary-cards {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }
        
        .card {
            background: var(--card-bg);
            border-radius: 10px;
            padding: 20px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.2);
            border: 1px solid rgba(255, 255, 255, 0.1);
        }
        
        .card h3 {
            margin-top: 0;
            color: var(--primary-neon);
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
            padding-bottom: 10px;
        }
        
        .metric {
            display: flex;
            justify-content: space-between;
            margin: 10px 0;
        }
        
        .metric-label {
            color: #A0A7D6;
        }
        
        .metric-value {
            font-weight: bold;
            color: var(--primary-neon);
        }
        
        .jobs-table {
            width: 100%;
            border-collapse: collapse;
            background: var(--card-bg);
            border-radius: 10px;
            overflow: hidden;
        }
        
        .jobs-table th {
            background-color: rgba(0, 242, 255, 0.15);
            padding: 15px;
            text-align: left;
            color: var(--primary-neon);
        }
        
        .jobs-table td {
            padding: 15px;
            border-bottom: 1px solid rgba(255, 255, 255, 0.05);
        }
        
        .status-running {
            color: #00FF00;
            font-weight: bold;
        }
        
        .status-success {
            color: #00FF00;
        }
        
        .status-failed {
            color: #FF0000;
        }
        
        .progress-bar {
            height: 10px;
            background-color: rgba(255, 255, 255, 0.1);
            border-radius: 5px;
            overflow: hidden;
        }
        
        .progress-fill {
            height: 100%;
            background: linear-gradient(90deg, var(--primary-neon), var(--secondary-neon));
            border-radius: 5px;
        }
        
        .stage-info {
            display: flex;
            justify-content: space-between;
            margin-top: 5px;
            font-size: 14px;
            color: #A0A7D6;
        }
        
        .console-output {
            background: #1a1f36;
            border-radius: 8px;
            padding: 15px;
            font-family: 'Courier New', monospace;
            font-size: 14px;
            color: #00F2FF;
            height: 300px;
            overflow-y: auto;
            border: 1px solid rgba(0, 242, 255, 0.3);
        }
        
        .console-line {
            margin: 5px 0;
        }
        
        .warning {
            color: #FFD700;
        }
        
        .error {
            color: #FF6B6B;
        }
        
        .info {
            color: #4ECDC4;
        }
        
        .action-buttons {
            display: flex;
            gap: 10px;
            margin: 20px 0;
        }
        
        .btn {
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-weight: bold;
            transition: all 0.3s ease;
        }
        
        .btn-primary {
            background: linear-gradient(90deg, var(--primary-neon), var(--secondary-neon));
            color: var(--bg-dark);
        }
        
        .btn-secondary {
            background-color: rgba(255, 255, 255, 0.1);
            color: var(--text-main);
        }
        
        .btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.3);
        }
    </style>
</head>
<body>
    <header>
        <div class="header-content">
            <h1>Spark Web UI - HashTrack Analysis</h1>
            <div class="nav-tabs">
                <a href="#" class="nav-tab active">Jobs</a>
                <a href="#" class="nav-tab">Stages</a>
                <a href="#" class="nav-tab">Storage</a>
                <a href="#" class="nav-tab">Environment</a>
                <a href="#" class="nav-tab">Executors</a>
            </div>
        </div>
    </header>
    
    <div class="container">
        <div class="action-buttons">
            <button class="btn btn-primary" id="refreshBtn">Refresh Data</button>
            <button class="btn btn-secondary" id="exportBtn">Export Results</button>
            <button class="btn btn-secondary" id="viewResultsBtn">View Analysis Results</button>
        </div>
        
        <div class="summary-cards">
            <div class="card">
                <h3>Cluster Summary</h3>
                <div class="metric">
                    <span class="metric-label">Active Workers:</span>
                    <span class="metric-value">2</span>
                </div>
                <div class="metric">
                    <span class="metric-label">Cores:</span>
                    <span class="metric-value">4</span>
                </div>
                <div class="metric">
                    <span class="metric-label">Memory:</span>
                    <span class="metric-value">4.0 GB</span>
                </div>
            </div>
            
            <div class="card">
                <h3>Application Status</h3>
                <div class="metric">
                    <span class="metric-label">Status:</span>
                    <span class="metric-value status-running">RUNNING</span>
                </div>
                <div class="metric">
                    <span class="metric-label">Start Time:</span>
                    <span class="metric-value" id="startTime">2025/11/25 14:30:22</span>
                </div>
                <div class="metric">
                    <span class="metric-label">Duration:</span>
                    <span class="metric-value" id="duration">00:00:00</span>
                </div>
            </div>
            
            <div class="card">
                <h3>Job Progress</h3>
                <div class="metric">
                    <span class="metric-label">Active Jobs:</span>
                    <span class="metric-value">1</span>
                </div>
                <div class="metric">
                    <span class="metric-label">Completed Jobs:</span>
                    <span class="metric-value" id="completedJobs">0</span>
                </div>
                <div class="metric">
                    <span class="metric-label">Failed Jobs:</span>
                    <span class="metric-value">0</span>
                </div>
            </div>
        </div>
        
        <div class="card">
            <h3>Active Jobs</h3>
            <table class="jobs-table">
                <thead>
                    <tr>
                        <th>Job ID</th>
                        <th>Description</th>
                        <th>Submitted</th>
                        <th>Duration</th>
                        <th>Stages</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>4</td>
                        <td>Smart Hashtag Analysis - Clustering</td>
                        <td>2025/11/25 14:42:15</td>
                        <td id="jobDuration">00:00:00</td>
                        <td>
                            <div class="progress-bar">
                                <div class="progress-fill" id="jobProgress" style="width: 0%"></div>
                            </div>
                            <div class="stage-info">
                                <span id="progressText">0% Complete</span>
                                <span id="tasksText">0/20 Tasks</span>
                            </div>
                        </td>
                        <td class="status-running">RUNNING</td>
                    </tr>
                </tbody>
            </table>
        </div>
        
        <div class="card">
            <h3>Console Output</h3>
            <div class="console-output" id="consoleOutput">
                <div class="console-line">23/11/25 14:30:22 INFO SparkContext: Running Spark version 3.5.3</div>
                <div class="console-line">23/11/25 14:30:22 INFO SparkContext: Submitted application: HashTrack Smart Analysis</div>
                <div class="console-line">23/11/25 14:30:23 INFO SparkUI: Bound SparkUI to 0.0.0.0, and started at http://localhost:4042</div>
                <div class="console-line">23/11/25 14:30:25 INFO SparkContext: Successfully created SparkContext</div>
                <div class="console-line">23/11/25 14:30:30 INFO HashTrack: Loading dataset from social_media_hashtag_trends_3000_rows.csv</div>
                <div class="console-line">23/11/25 14:30:35 INFO HashTrack: Dataset loaded successfully (3000 rows)</div>
                <div class="console-line">23/11/25 14:32:15 INFO HashTrack: Starting hashtag co-occurrence analysis</div>
                <div class="console-line">23/11/25 14:33:45 INFO HashTrack: Processing co-occurrence matrix (25%)</div>
                <div class="console-line">23/11/25 14:35:20 INFO HashTrack: Co-occurrence analysis completed</div>
                <div class="console-line">23/11/25 14:36:30 INFO HashTrack: Starting sentiment analysis preprocessing</div>
            </div>
        </div>
    </div>
    
    <script>
        // Button event handlers
        document.getElementById('refreshBtn').addEventListener('click', function() {
            alert('Refreshing job data...');
            // In a real implementation, this would fetch updated data from the server
        });
        
        document.getElementById('exportBtn').addEventListener('click', function() {
            alert('Exporting results to CSV...');
            // In a real implementation, this would trigger a download of the results
        });
        
        document.getElementById('viewResultsBtn').addEventListener('click', function() {
            alert('Opening analysis results in new tab...');
            // In a real implementation, this would open the results page
        });
        
        // Simulate job progress
        let progress = 0;
        let startTime = new Date();
        let completedJobs = 0;
        
        function updateTimer() {
            const now = new Date();
            const elapsed = new Date(now - startTime);
            const hours = elapsed.getUTCHours().toString().padStart(2, '0');
            const minutes = elapsed.getUTCMinutes().toString().padStart(2, '0');
            const seconds = elapsed.getUTCSeconds().toString().padStart(2, '0');
            document.getElementById('duration').textContent = `${hours}:${minutes}:${seconds}`;
        }
        
        function addConsoleLine(message, className = '') {
            const consoleOutput = document.getElementById('consoleOutput');
            const newLine = document.createElement('div');
            newLine.className = 'console-line ' + className;
            newLine.textContent = message;
            consoleOutput.appendChild(newLine);
            consoleOutput.scrollTop = consoleOutput.scrollHeight;
        }
        
        // Simulate job progression
        const jobSteps = [
            {time: 2000, message: "23/11/25 14:38:45 INFO HashTrack: Sentiment analysis preprocessing complete", progress: 50},
            {time: 2000, message: "23/11/25 14:40:15 INFO HashTrack: Starting smart hashtag clustering analysis", progress: 60},
            {time: 2000, message: "23/11/25 14:42:15 INFO HashTrack: Processing cluster 1/3", progress: 65},
            {time: 2000, message: "23/11/25 14:43:45 INFO HashTrack: Processing cluster 2/3", progress: 75},
            {time: 2000, message: "23/11/25 14:45:30 INFO HashTrack: Processing cluster 3/3", progress: 85},
            {time: 2000, message: "23/11/25 14:47:15 INFO HashTrack: Clustering completed. Found 3 distinct clusters", progress: 95},
            {time: 2000, message: "23/11/25 14:48:30 INFO HashTrack: Generating cluster insights", progress: 98},
            {time: 2000, message: "23/11/25 14:50:00 INFO HashTrack: Analysis complete! Results saved to output directory", progress: 100}
        ];
        
        let stepIndex = 0;
        
        function runJobSimulation() {
            if (stepIndex < jobSteps.length) {
                setTimeout(() => {
                    const step = jobSteps[stepIndex];
                    progress = step.progress;
                    
                    // Update progress bar
                    document.getElementById('jobProgress').style.width = progress + '%';
                    document.getElementById('progressText').textContent = progress + '% Complete';
                    
                    // Update tasks (assuming 20 total tasks)
                    const completedTasks = Math.floor(20 * (progress / 100));
                    document.getElementById('tasksText').textContent = completedTasks + '/20 Tasks';
                    
                    // Add console line
                    addConsoleLine(step.message);
                    
                    // Update job duration
                    updateTimer();
                    
                    stepIndex++;
                    runJobSimulation();
                }, jobSteps[stepIndex].time);
            } else {
                // Job completed
                document.getElementById('jobProgress').style.width = '100%';
                document.getElementById('progressText').textContent = '100% Complete';
                document.getElementById('tasksText').textContent = '20/20 Tasks';
                document.querySelector('.status-running').className = 'status-success';
                document.querySelector('.status-running').textContent = 'SUCCESS';
                addConsoleLine("23/11/25 14:50:00 INFO SparkUI: Job completed successfully!", "info");
                addConsoleLine("23/11/25 14:50:00 INFO SparkContext: Spark UI will remain available for 5 minutes", "info");
                completedJobs++;
                document.getElementById('completedJobs').textContent = completedJobs;
                
                // Show completion message
                setTimeout(() => {
                    addConsoleLine("============================================================", "info");
                    addConsoleLine("SPARK JOB COMPLETED SUCCESSFULLY!", "info");
                    addConsoleLine("Results saved to: output/smart_analysis/", "info");
                    addConsoleLine("============================================================", "info");
                    addConsoleLine("Spark UI will remain available at http://localhost:4042", "info");
                    addConsoleLine("Press Ctrl+C to stop the server", "info");
                }, 2000);
            }
        }
        
        // Start the timer and job simulation
        setInterval(updateTimer, 1000);
        // Start job simulation after initial delay
        setTimeout(runJobSimulation, 3000);
    </script>
</body>
</html>'''