import asyncio, json, random
import websockets
import traceback
import sys

clients = set()

async def handler(websocket, path=None):
    # Register the client
    clients.add(websocket)
    print(f"Client connected. Total clients: {len(clients)}")
    try:
        # Send an initial message to the client
        await websocket.send(json.dumps({"status": "connected", "message": "Welcome to HashTrack WebSocket server"}))
        
        # Keep the connection alive and handle messages
        async for message in websocket:
            print(f"Received message: {message}")
            # Echo the message back
            await websocket.send(message)
    except websockets.exceptions.ConnectionClosed:
        print("Client disconnected")
    except Exception as e:
        print(f"Error handling client: {e}")
        print(f"Traceback: {traceback.format_exc()}")
        # Print to stderr as well
        print(f"Error handling client: {e}", file=sys.stderr)
        print(f"Traceback: {traceback.format_exc()}", file=sys.stderr)
    finally:
        # Unregister the client
        clients.discard(websocket)
        print(f"Client removed. Total clients: {len(clients)}")

async def broadcaster():
    counter = 0
    while True:
        if clients:
            try:
                # Send live data in the format expected by the frontend
                payload = json.dumps({
                    "hashtag": "#demo",
                    "intensity": round(random.random(), 3),
                    "alert": None
                })
                print(f"Broadcasting to {len(clients)} clients: {payload}")
                # Send to all connected clients
                disconnected_clients = set()
                for client in clients.copy():  # Use copy to avoid modification during iteration
                    try:
                        # Check if the connection is still open
                        if client.state == websockets.protocol.State.OPEN:
                            await client.send(payload)
                    except websockets.exceptions.ConnectionClosed:
                        disconnected_clients.add(client)
                    except Exception as e:
                        print(f"Error sending to client: {e}")
                        print(f"Traceback: {traceback.format_exc()}")
                        disconnected_clients.add(client)
                
                # Remove disconnected clients
                for client in disconnected_clients:
                    clients.discard(client)
                    
            except Exception as e:
                print(f"Error in broadcaster: {e}")
                print(f"Traceback: {traceback.format_exc()}")
        else:
            print(f"No clients connected, skipping broadcast #{counter}")
        counter += 1
        await asyncio.sleep(2)

async def main():
    # Start the server
    server = await websockets.serve(handler, "localhost", 6000)
    print("WebSocket server started on ws://localhost:6000")
    
    # Start the broadcaster
    asyncio.create_task(broadcaster())
    
    # Keep the server running
    await server.wait_closed()

if __name__ == '__main__':
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        print("Server stopped")
    except Exception as e:
        print(f"Server error: {e}")
        print(f"Traceback: {traceback.format_exc()}")
        # Print to stderr as well
        print(f"Server error: {e}", file=sys.stderr)
        print(f"Traceback: {traceback.format_exc()}", file=sys.stderr)