import json
import os

# Create sample co-occurrence data
data = {
    "nodes": [
        {"id": "#Photography"},
        {"id": "#SustainableLiving"},
        {"id": "#StartupLife"},
        {"id": "#BookLovers"},
        {"id": "#TechInnovation"},
        {"id": "#FitnessGoals"},
        {"id": "#FoodieLife"},
        {"id": "#MentalHealth"},
        {"id": "#DigitalArt"},
        {"id": "#TravelDiaries"}
    ],
    "links": [
        {"source": "#Photography", "target": "#DigitalArt", "value": 15},
        {"source": "#SustainableLiving", "target": "#MentalHealth", "value": 12},
        {"source": "#StartupLife", "target": "#TechInnovation", "value": 18},
        {"source": "#BookLovers", "target": "#MentalHealth", "value": 9},
        {"source": "#FitnessGoals", "target": "#FoodieLife", "value": 11},
        {"source": "#TravelDiaries", "target": "#Photography", "value": 14}
    ]
}

# Write to output directory
output_file = os.path.join('output', 'cooccurrence.json')
with open(output_file, 'w') as f:
    json.dump(data, f)

print(f"Co-occurrence data saved to {output_file}")