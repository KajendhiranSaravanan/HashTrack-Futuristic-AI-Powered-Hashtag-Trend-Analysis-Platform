#!/usr/bin/env python
"""
Smart Hashtag Trend Analysis with Spark
Adapted for local Windows environment
"""
import sys
import os
from pyspark.sql import SparkSession
from pyspark.sql.functions import col, avg, count, desc, when, sum as spark_sum
import json
import csv

def main(input_path, output_path):
    # Start SparkSession with Web UI on port 4042
    spark = (
        SparkSession.builder
        .appName("Smart_Hashtag_Trend_Analysis")
        .config("spark.sql.shuffle.partitions", "4")
        .config("spark.default.parallelism", "4")
        .config("spark.sql.adaptive.enabled", "true")
        .config("spark.sql.adaptive.coalescePartitions.enabled", "true")
        .config("spark.ui.port", "4042")
        .getOrCreate()
    )
    
    print("[SUCCESS] Spark started successfully!")
    # Get the actual UI port (in case 4042 was busy and Spark chose another)
    actual_port = spark.sparkContext.uiWebUrl.split(':')[-1].rstrip('/') if spark.sparkContext.uiWebUrl else "4042"
    print("[INFO] Spark Web UI available at: http://localhost:" + actual_port)
    
    # Load data into Spark - OPTIMIZED: Sample data for faster processing
    data = (
        spark.read.option("header", "true")
        .option("inferSchema", "true")
        .csv(input_path)
    )
    
    # Sample 50% of data for faster processing (adjust as needed)
    data = data.sample(0.5, seed=42)
    
    print("[SUCCESS] CSV loaded successfully! Total rows:", data.count())
    
    # Pre-processing and feature engineering
    data = data.na.fill(0)
    data = data.withColumn("engagement", col("likes") + col("comments") + col("shares"))
    
    # Convert sentiment_score if needed (already numeric in your dataset)
    # Ensure all required columns exist
    if "trend_score" not in data.columns:
        data = data.withColumn("trend_score", col("virality_score"))
    
    # Find the most popular hashtags based on various metrics
    popular_hashtags = (
        data.groupBy("hashtag")
        .agg(
            count("*").alias("mention_count"),
            avg("engagement").alias("avg_engagement"),
            avg("reach").alias("avg_reach"),
            avg("sentiment_score").alias("avg_sentiment"),
            spark_sum("likes").alias("total_likes"),
            spark_sum("comments").alias("total_comments"),
            spark_sum("shares").alias("total_shares")
        )
        .orderBy(desc("mention_count"), desc("avg_engagement"))
        .limit(30)  # Reduced from 100 to 30 hashtags for faster processing
    )
    
    print("[SUCCESS] Popular hashtags analysis complete!")
    popular_hashtags.show(5)  # Show fewer rows for faster output
    
    # Save results
    os.makedirs(output_path, exist_ok=True)
    
    # Save as JSON for web display
    popular_list = []
    for row in popular_hashtags.collect():
        popular_list.append({
            "hashtag": str(row["hashtag"]),
            "mention_count": int(row["mention_count"]),
            "avg_engagement": float(row["avg_engagement"]),
            "avg_reach": float(row["avg_reach"]),
            "avg_sentiment": float(row["avg_sentiment"]),
            "total_likes": int(row["total_likes"]),
            "total_comments": int(row["total_comments"]),
            "total_shares": int(row["total_shares"])
        })
    
    json_output = os.path.join(output_path, "popular_hashtags.json")
    with open(json_output, 'w') as f:
        json.dump(popular_list, f, indent=2)
    
    # Save as CSV for Excel download
    csv_output = os.path.join(output_path, "popular_hashtags.csv")
    with open(csv_output, 'w', newline='', encoding='utf-8') as csvfile:
        fieldnames = ["hashtag", "mention_count", "avg_engagement", "avg_reach", "avg_sentiment", "total_likes", "total_comments", "total_shares"]
        writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
        writer.writeheader()
        for item in popular_list:
            writer.writerow(item)
    
    print("[SUCCESS] Results saved to:", output_path)
    print("[COMPLETE] Analysis complete!")
    print("")
    print("="*60)
    print("[INFO] SPARK WEB UI IS NOW AVAILABLE AT:")
    print("   http://localhost:" + actual_port)
    print("="*60)
    print("")
    print("[INFO] Keeping Spark UI alive for 5 minutes...")
    print("   Open http://localhost:" + actual_port + " in your browser NOW to view:")
    print("   - Jobs and Stages")
    print("   - DAG Visualization")
    print("   - Executors")
    print("   - Storage")
    print("   - Environment")
    print("")
    print("Press Ctrl+C to stop and close Spark UI")
    print("")
    
    # Keep Spark UI alive for only 30 seconds (reduced from 5 minutes)
    import time
    try:
        for i in range(30, 0, -5):
            print(f"\rSpark UI available for {i} more seconds...", end='', flush=True)
            time.sleep(5)
        print("\n\nTime's up! Closing Spark UI...")
    except KeyboardInterrupt:
        print("\n\n[WARNING] Interrupted by user. Closing Spark UI...")
    
    spark.stop()

if __name__ == "__main__":
    if len(sys.argv) < 3:
        print("Usage: spark-submit smart_analysis_spark.py input.csv output_dir")
        sys.exit(1)
    
    input_file = sys.argv[1]
    output_dir = sys.argv[2]
    main(input_file, output_dir)
