# HashTrack Spark - cluster_hashtags_spark.py
from pyspark.sql import SparkSession, functions as F
from pyspark.ml.feature import Tokenizer, HashingTF, IDF
from pyspark.ml.clustering import KMeans
import sys, os

# Create Spark session with configurations optimized for speed
spark = SparkSession.builder.appName("HashTrackClusters").\
    config("spark.hadoop.io.native.lib.available", "false").\
    config("spark.sql.adaptive.enabled", "false").\
    config("spark.hadoop.mapreduce.fileoutputcommitter.algorithm.version", "2").\
    config("spark.hadoop.mapreduce.fileoutputcommitter.task.attempt.id", "").\
    config("spark.hadoop.dfs.client.use.datanode.hostname", "false").\
    config("spark.sql.execution.arrow.pyspark.enabled", "false").\
    config("spark.serializer", "org.apache.spark.serializer.KryoSerializer").\
    config("spark.sql.shuffle.partitions", "4").\
    config("spark.default.parallelism", "4").getOrCreate()

if len(sys.argv)<3:
    print("usage: spark-submit cluster_hashtags_spark.py input.csv output_dir"); sys.exit(1)

input_path, output_path = sys.argv[1], sys.argv[2]

# Ensure output directory exists
os.makedirs(output_path, exist_ok=True)

# Read and process data - OPTIMIZED: Sample data for faster processing
df = spark.read.option("header","true").csv(input_path)
# Sample 30% of data for faster processing
df = df.sample(0.3, seed=42)

# Since there's no 'id' column in the actual data, we'll use the available columns
# Available columns: hashtag,platform,text,post_time,likes,comments,shares,reach,country,device,category,engagement_rate,sentiment_score,virality_score
df_selected = df.select('hashtag','category')

# Limit to top hashtags for faster processing
top_hashtags = df_selected.groupBy('hashtag').count().orderBy(F.desc('count')).limit(500)
df_selected = df_selected.join(top_hashtags, on='hashtag', how='inner')

expl = df_selected.groupBy('hashtag').agg(F.collect_list('category').alias('cats')).withColumn('text', F.concat_ws(' ', 'cats'))
tokenizer = Tokenizer(inputCol='text', outputCol='words')
wordsData = tokenizer.transform(expl)
hashTF = HashingTF(inputCol='words', outputCol='rawFeatures', numFeatures=512)  # Reduced features for speed
featurizedData = hashTF.transform(wordsData)
idf = IDF(inputCol='rawFeatures', outputCol='features').fit(featurizedData)
res = idf.transform(featurizedData)
kmeans = KMeans(k=4, seed=42, featuresCol='features', predictionCol='cluster').fit(res)  # Reduced clusters for speed
out = kmeans.transform(res).select(F.col('hashtag'), 'cluster')

# Collect results locally and write as JSON to avoid FileOutputCommitter issues
try:
    # Collect data to driver
    results = out.collect()
    
    # Convert to dictionary format
    output_data = []
    for row in results:
        output_data.append({
            "hashtag": row["hashtag"],
            "cluster": int(row["cluster"])
        })
    
    # Write to JSON file using Python's built-in JSON module
    import json
    output_file = os.path.join(output_path, "cluster_results.json")
    with open(output_file, "w") as f:
        json.dump(output_data, f)
    
    print(f"Successfully wrote {len(output_data)} records to {output_file}")
    
except Exception as e:
    print(f"Error processing data: {str(e)}")
    # Create empty results file as fallback
    import json
    output_file = os.path.join(output_path, "cluster_results.json")
    with open(output_file, "w") as f:
        json.dump([], f)

spark.stop()