# HashTrack Spark - cooccurrence_spark.py
from pyspark.sql import SparkSession, functions as F
import sys, os, json

# Create Spark session with configurations optimized for speed
spark = SparkSession.builder.appName("HashTrackCooccurrence").\
    config("spark.hadoop.io.native.lib.available", "false").\
    config("spark.sql.adaptive.enabled", "false").\
    config("spark.hadoop.mapreduce.fileoutputcommitter.algorithm.version", "2").\
    config("spark.hadoop.mapreduce.fileoutputcommitter.task.attempt.id", "").\
    config("spark.hadoop.dfs.client.use.datanode.hostname", "false").\
    config("spark.sql.execution.arrow.pyspark.enabled", "false").\
    config("spark.serializer", "org.apache.spark.serializer.KryoSerializer").\
    config("spark.sql.shuffle.partitions", "4").\
    config("spark.default.parallelism", "4").getOrCreate()

if len(sys.argv) < 3:
    print("usage: spark-submit cooccurrence_spark.py input.csv output_dir")
    sys.exit(1)

input_path, output_path = sys.argv[1], sys.argv[2]

# Ensure output directory exists
os.makedirs(output_path, exist_ok=True)

try:
    # Read the data (using actual column names from the CSV) - OPTIMIZED: Sample data for faster processing
    df = spark.read.option("header", "true").csv(input_path).select('hashtag', 'category')
    # Sample 30% of data for faster processing
    df = df.sample(0.3, seed=42)
    
    # Get top hashtags
    top_hashtags = df.groupBy('hashtag').count().orderBy(F.desc('count')).limit(50)  # Reduced limit for speed
    
    # Join to get categories for top hashtags
    top_df = df.join(top_hashtags, on='hashtag', how='inner')
    
    # Create pairs of hashtags that appear in the same category
    # First, let's create a dataframe with hashtag-category pairs
    hashtag_categories = top_df.select('hashtag', 'category').distinct()
    
    # Self-join to find hashtag pairs in the same category
    hashtag_pairs = hashtag_categories.alias('a').join(
        hashtag_categories.alias('b'),
        (F.col('a.category') == F.col('b.category')) & 
        (F.col('a.hashtag') != F.col('b.hashtag')) &
        (F.col('a.hashtag') < F.col('b.hashtag'))  # Avoid duplicates
    ).select(
        F.col('a.hashtag').alias('hashtag1'),
        F.col('b.hashtag').alias('hashtag2'),
        'a.category'
    )
    
    # Count co-occurrences - Limit for faster processing
    cooccurrence_counts = hashtag_pairs.groupBy('hashtag1', 'hashtag2').count().orderBy(F.desc('count')).limit(100)  # Reduced limit for speed
    
    # Collect data to driver
    nodes_data = top_hashtags.select('hashtag').collect()
    links_data = cooccurrence_counts.collect()
    
    # Create nodes list
    nodes = [{'id': row['hashtag']} for row in nodes_data]
    
    # Create links list
    links = [{'source': row['hashtag1'], 'target': row['hashtag2'], 'value': int(row['count'])} for row in links_data]
    
    # Save co-occurrence data as JSON using Python's built-in JSON module
    cooccurrence_data = {'nodes': nodes, 'links': links}
    cooccurrence_file = os.path.join(output_path, 'cooccurrence.json')
    
    print(f"Saving co-occurrence data to {cooccurrence_file}")
    print(f"Nodes count: {len(nodes)}")
    print(f"Links count: {len(links)}")
    
    with open(cooccurrence_file, 'w') as f:
        json.dump(cooccurrence_data, f)
    
    # Also save the raw counts for reference
    counts_data = df.groupBy('hashtag').count().orderBy(F.desc('count')).limit(100)  # Reduced limit for speed
    counts_records = counts_data.collect()
    
    # Convert to dictionary format
    counts_output = []
    for row in counts_records:
        counts_output.append({
            "hashtag": row["hashtag"],
            "count": int(row["count"])
        })
    
    # Save counts data
    counts_file = os.path.join(output_path, "hashtag_counts.json")
    with open(counts_file, 'w') as f:
        json.dump(counts_output, f)
    
    print("Co-occurrence data successfully generated")
    
except Exception as e:
    print(f"Error generating co-occurrence data: {str(e)}")
    import traceback
    traceback.print_exc()
    # Create empty co-occurrence file as fallback
    cooccurrence_file = os.path.join(output_path, 'cooccurrence.json')
    with open(cooccurrence_file, 'w') as f:
        json.dump({'nodes': [], 'links': []}, f)

spark.stop()