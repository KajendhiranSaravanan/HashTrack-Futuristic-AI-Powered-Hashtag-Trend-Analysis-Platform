# HashTrack Spark - trending_spark.py
from pyspark.sql import SparkSession, functions as F, Window
import sys, os

# Create Spark session with configurations optimized for speed
spark = SparkSession.builder.appName("HashTrackTrending").\
    config("spark.hadoop.io.native.lib.available", "false").\
    config("spark.sql.adaptive.enabled", "false").\
    config("spark.hadoop.mapreduce.fileoutputcommitter.algorithm.version", "2").\
    config("spark.hadoop.mapreduce.fileoutputcommitter.task.attempt.id", "").\
    config("spark.hadoop.dfs.client.use.datanode.hostname", "false").\
    config("spark.sql.execution.arrow.pyspark.enabled", "false").\
    config("spark.serializer", "org.apache.spark.serializer.KryoSerializer").\
    config("spark.sql.shuffle.partitions", "4").\
    config("spark.default.parallelism", "4").getOrCreate()

if len(sys.argv)<3:
    print("usage: spark-submit trending_spark.py input.csv output_dir"); sys.exit(1)

input_path, output_path = sys.argv[1], sys.argv[2]

# Ensure output directory exists
os.makedirs(output_path, exist_ok=True)

# Read and process data - OPTIMIZED: Sample data for faster processing
df = spark.read.option("header","true").csv(input_path)
# Sample 20% of data for faster processing
df = df.sample(0.2, seed=42)
df = df.withColumn("date", F.to_date(F.col("post_time")))

# Remove date filtering to include all data since it's from 2024
# daily = df.groupBy("hashtag","date").count()
daily = df.groupBy("hashtag","date").count()
w = Window.partitionBy("hashtag").orderBy("date")
res = daily.withColumn("prev_count", F.lag("count").over(w))
res = res.withColumn("trend_score", F.when(F.col("prev_count").isNull(), 0.0).otherwise((F.col("count")-F.col("prev_count"))/F.col("prev_count")*100))

# Further optimize by limiting results
res = res.orderBy(F.desc("trend_score")).limit(1000)

# Collect results locally and write as JSON to avoid FileOutputCommitter issues
try:
    # Collect data to driver
    results = res.collect()
    
    # Convert to dictionary format
    output_data = []
    for row in results:
        output_data.append({
            "hashtag": row["hashtag"],
            "date": str(row["date"]) if row["date"] else None,
            "count": row["count"],
            "prev_count": row["prev_count"],
            "trend_score": float(row["trend_score"]) if row["trend_score"] is not None else 0.0
        })
    
    # Write to JSON file using Python's built-in JSON module
    import json
    output_file = os.path.join(output_path, "trending_results.json")
    with open(output_file, "w") as f:
        json.dump(output_data, f)
    
    print(f"Successfully wrote {len(output_data)} records to {output_file}")
    
except Exception as e:
    print(f"Error processing data: {str(e)}")
    # Create empty results file as fallback
    import json
    output_file = os.path.join(output_path, "trending_results.json")
    with open(output_file, "w") as f:
        json.dump([], f)

spark.stop()