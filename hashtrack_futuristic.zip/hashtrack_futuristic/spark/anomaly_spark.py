# HashTrack Spark - anomaly_spark.py
from pyspark.sql import SparkSession, functions as F, Window
import sys, os
spark = SparkSession.builder.appName("HashTrackAnomaly").getOrCreate()
if len(sys.argv)<3:
    print("usage: spark-submit anomaly_spark.py trending_json_dir output_dir"); sys.exit(1)
input_path, output_path = sys.argv[1], sys.argv[2]
os.makedirs(output_path, exist_ok=True)
df = spark.read.json(input_path)
w = Window.partitionBy('hashtag').orderBy('date').rowsBetween(-7, -1)
df2 = df.withColumn('mean7', F.avg('count').over(w)).withColumn('std7', F.stddev('count').over(w))
df3 = df2.withColumn('z', (F.col('count')-F.col('mean7'))/F.col('std7')).withColumn('anomaly', F.when(F.col('z')>3, True).otherwise(False))
df3.write.mode('overwrite').json(output_path)
spark.stop()
