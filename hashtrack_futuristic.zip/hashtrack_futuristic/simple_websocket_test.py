import asyncio
import websockets

async def test_connection():
    uri = "ws://localhost:6000"
    try:
        async with websockets.connect(uri) as websocket:
            print("Connected to WebSocket server")
            # Send a simple message
            await websocket.send("Hello Server")
            # Wait for a response
            response = await websocket.recv()
            print(f"Received: {response}")
            print("WebSocket connection test successful")
    except Exception as e:
        print(f"WebSocket connection failed: {e}")

# Run the test
asyncio.run(test_connection())