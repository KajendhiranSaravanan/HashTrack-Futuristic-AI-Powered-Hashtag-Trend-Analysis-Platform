#!/usr/bin/env python3
"""
Script to start a Spark job with Web UI accessible on localhost
"""
import subprocess
import sys
import os
import time
import webbrowser

def start_spark_job_with_ui():
    # Get the project paths
    project_root = os.path.dirname(os.path.abspath(__file__))
    spark_script = os.path.join(project_root, 'spark', 'trending_spark.py')
    data_path = os.path.join(project_root, 'social_media_hashtag_trends_3000_rows.csv')
    output_path = os.path.join(project_root, 'output', 'web_ui_test')
    
    # Create output directory
    os.makedirs(output_path, exist_ok=True)
    
    # Spark submit command
    spark_submit_cmd = r'C:\spark\spark-4.0.1-bin-hadoop3\spark-4.0.1-bin-hadoop3\bin\spark-submit.cmd'
    
    # Check if files exist
    if not os.path.exists(spark_script):
        print(f"❌ Spark script not found: {spark_script}")
        return False
        
    if not os.path.exists(data_path):
        print(f"❌ Data file not found: {data_path}")
        return False
        
    # Set environment variables
    env = os.environ.copy()
    env['PYSPARK_PYTHON'] = r'C:\Users\sarva\AppData\Local\Programs\Python\Python310\python.exe'
    env['JAVA_HOME'] = r'C:\Program Files\Eclipse Adoptium\jdk-17.0.17.10-hotspot'
    
    # Build command with UI configuration
    cmd = [
        spark_submit_cmd,
        "--conf", "spark.ui.host=localhost",
        "--conf", "spark.driver.host=localhost",
        "--conf", "spark.driver.bindAddress=127.0.0.1",
        spark_script,
        data_path,
        output_path
    ]
    
    print("🚀 Starting Spark job with Web UI on localhost...")
    print(f"📝 Script: {spark_script}")
    print(f"📂 Data: {data_path}")
    print(f"💾 Output: {output_path}")
    print(f"🌐 Web UI will be available at: http://localhost:4040")
    print("=" * 60)
    
    try:
        # Start the Spark job
        process = subprocess.Popen(
            cmd, 
            stdout=subprocess.PIPE, 
            stderr=subprocess.STDOUT, 
            text=True, 
            env=env,
            bufsize=1
        )
        
        print("📊 Spark job started! Waiting for Web UI to be ready...")
        print("📝 Job output:")
        print("-" * 40)
        
        # Look for the Web UI message in the output
        web_ui_url = None
        start_time = time.time()
        timeout = 60  # 60 seconds timeout
        
        while time.time() - start_time < timeout:
            output = process.stdout.readline()
            if output:
                print(output.strip())
                
                # Look for Web UI URL in the output
                if 'Spark web UI' in output and 'http://' in output:
                    # Extract URL from line like "Stopped Spark web UI at http://kajendhiran:4041"
                    import re
                    match = re.search(r'http://[^\s]+', output)
                    if match:
                        url = match.group(0)
                        # Replace hostname with localhost
                        web_ui_url = url.replace(url.split(':')[1][2:].split('/')[0], 'localhost')
                        print(f"\n✅ Spark Web UI detected: {web_ui_url}")
                        print("Opening browser...")
                        webbrowser.open(web_ui_url)
                        break
                        
                if 'Bound SparkUI to' in output:
                    # Extract URL from line like "Bound SparkUI to 0.0.0.0, and started at http://kajendhiran:4040"
                    import re
                    match = re.search(r'http://[^\s]+', output)
                    if match:
                        url = match.group(0)
                        # Replace hostname with localhost
                        web_ui_url = url.replace(url.split(':')[1][2:].split('/')[0], 'localhost')
                        print(f"\n✅ Spark Web UI bound: {web_ui_url}")
                        print("Opening browser...")
                        webbrowser.open(web_ui_url)
                        break
                        
                # Look for port binding messages
                if 'Starting SparkUI at' in output:
                    import re
                    match = re.search(r'http://[^\s]+', output)
                    if match:
                        url = match.group(0)
                        # Replace hostname with localhost
                        web_ui_url = url.replace(url.split(':')[1][2:].split('/')[0], 'localhost')
                        print(f"\n✅ Spark Web UI starting: {web_ui_url}")
                        print("Opening browser...")
                        webbrowser.open(web_ui_url)
                        break
            
            # Check if process has ended
            if process.poll() is not None:
                break
        
        if web_ui_url:
            print(f"\n🎯 Spark Web UI is now accessible at: {web_ui_url}")
            print("Press Ctrl+C to stop the job...")
            
            # Keep the process running
            try:
                # Continue reading output
                while True:
                    output = process.stdout.readline()
                    if output:
                        print(output.strip())
                    if process.poll() is not None:
                        break
            except KeyboardInterrupt:
                print("\n\n⚠️ Interrupted by user. Stopping Spark job...")
                process.terminate()
                try:
                    process.wait(timeout=10)
                except subprocess.TimeoutExpired:
                    process.kill()
                    process.wait()
                print("✅ Spark job stopped.")
        else:
            print("\n⚠️ Timeout waiting for Spark Web UI. Process output:")
            # Print remaining output
            while True:
                output = process.stdout.readline()
                if output:
                    print(output.strip())
                if process.poll() is not None:
                    break
                    
        return_code = process.poll()
        print(f"\n🏁 Spark job finished with return code: {return_code}")
        return return_code == 0
        
    except Exception as e:
        print(f"❌ Error running Spark job: {e}")
        return False

if __name__ == "__main__":
    success = start_spark_job_with_ui()
    sys.exit(0 if success else 1)