#!/usr/bin/env python3
"""
Test script to verify Spark Web UI functionality
"""
import subprocess
import sys
import os
import time
import requests

def test_spark_ui():
    print("Testing Spark Web UI availability...")
    
    # First check if Spark is installed
    spark_submit_cmd = 'spark-submit.cmd' if os.name == 'nt' else 'spark-submit'
    
    # Check if spark-submit exists
    import shutil
    spark_submit_found = shutil.which(spark_submit_cmd) or os.path.exists(spark_submit_cmd)
    
    if not spark_submit_found:
        print("❌ Apache Spark spark-submit command not found.")
        print("Please ensure Apache Spark is installed and spark-submit is in your PATH.")
        return False
    
    print("✅ Spark is installed")
    
    # Get the project paths
    project_root = os.path.dirname(os.path.abspath(__file__))
    spark_dir = os.path.join(project_root, 'spark')
    input_path = os.path.join(project_root, 'social_media_hashtag_trends_3000_rows.csv')
    output_path = os.path.join(project_root, 'output', 'ui_test')
    
    # Run a simple Spark job that keeps the UI alive
    script = os.path.join(spark_dir, 'smart_analysis_spark.py')
    
    print(f"Running Spark job: {script}")
    print(f"Input: {input_path}")
    print(f"Output: {output_path}")
    
    # Start the Spark job in the background
    cmd = [spark_submit_cmd, script, input_path, output_path]
    env = os.environ.copy()
    env['PYSPARK_PYTHON'] = 'python'
    
    try:
        print("Starting Spark job...")
        process = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, env=env)
        
        # Wait a moment for Spark to start
        time.sleep(5)
        
        # Check if the UI is available (using port 4042 as configured in smart_analysis_spark.py)
        print("Checking if Spark UI is available at http://localhost:4042...")
        try:
            response = requests.get('http://localhost:4042', timeout=5)
            if response.status_code == 200:
                print("✅ Spark Web UI is available!")
                print("You can now access http://localhost:4042/stages/ in your browser")
                print("The UI will be available for 5 minutes while the job runs")
                return True
            else:
                print(f"❌ Spark UI returned status code: {response.status_code}")
        except requests.exceptions.RequestException as e:
            print(f"❌ Failed to connect to Spark UI: {e}")
            
        # Wait for a bit to let the user access the UI
        print("Waiting 30 seconds for you to check the UI...")
        time.sleep(30)
        
        # Terminate the process
        process.terminate()
        try:
            process.wait(timeout=10)
        except subprocess.TimeoutExpired:
            process.kill()
            
        return True
        
    except Exception as e:
        print(f"❌ Error running Spark job: {e}")
        return False

if __name__ == "__main__":
    test_spark_ui()