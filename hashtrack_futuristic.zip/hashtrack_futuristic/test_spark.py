#!/usr/bin/env python3
"""
Test if PySpark works
"""
from pyspark.sql import SparkSession

def main():
    print("[INFO] Creating Spark session...")
    try:
        spark = SparkSession.builder \
            .appName("Test") \
            .config("spark.ui.port", "4042") \
            .getOrCreate()
        
        print("[SUCCESS] Spark session created!")
        print(f"[INFO] Spark Web UI: {spark.sparkContext.uiWebUrl}")
        
        # Create a simple DataFrame
        data = [("Alice", 1), ("Bob", 2), ("Charlie", 3)]
        df = spark.createDataFrame(data, ["Name", "Value"])
        df.show()
        
        print("[INFO] Test completed successfully!")
        print("[INFO] Keeping Spark session alive for 2 minutes...")
        print("[INFO] Access Spark Web UI at: http://localhost:4042")
        
        import time
        time.sleep(120)
        
        spark.stop()
        print("[INFO] Spark session stopped")
        
    except Exception as e:
        print(f"[ERROR] Failed to create Spark session: {e}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    main()