#!/usr/bin/env python3
"""
Interactive Spark runner that keeps the Spark UI available for monitoring
"""
import subprocess
import sys
import os
import signal
import time

def run_spark_job_interactive():
    if len(sys.argv) < 2:
        print("Usage: python run_spark_interactive.py <job_type> [input_path] [output_path]")
        print("Job types: trending, cooccurrence, clusters, anomaly, smart_analysis")
        sys.exit(1)
    
    job_type = sys.argv[1]
    
    # Get the project paths
    project_root = os.path.dirname(os.path.abspath(__file__))
    spark_dir = os.path.join(project_root, 'spark')
    
    # Default paths
    input_path = sys.argv[2] if len(sys.argv) > 2 else os.path.join(project_root, 'social_media_hashtag_trends_3000_rows.csv')
    output_path = sys.argv[3] if len(sys.argv) > 3 else os.path.join(project_root, 'output', f'{job_type}_interactive')
    
    # Determine which script to run
    if job_type == 'clusters':
        script = os.path.join(spark_dir, "cluster_hashtags_spark.py")
    elif job_type == 'smart_analysis':
        # Use the optimized API version for faster execution
        script = os.path.join(spark_dir, "smart_analysis_spark_api.py")
    else:
        script = os.path.join(spark_dir, f"{job_type}_spark.py")
    
    # Check if script exists
    if not os.path.exists(script):
        print(f"❌ Script not found: {script}")
        sys.exit(1)
    
    # Check if input file exists
    if not os.path.exists(input_path):
        print(f"❌ Input file not found: {input_path}")
        sys.exit(1)
    
    # Create output directory
    os.makedirs(output_path, exist_ok=True)
    
    # Spark submit command - updated to use the correct path
    spark_submit_cmd = r'C:\spark\spark-4.0.1-bin-hadoop3\spark-4.0.1-bin-hadoop3\bin\spark-submit.cmd' if os.name == 'nt' else 'spark-submit'
    
    # Check if spark-submit exists
    import shutil
    spark_submit_found = shutil.which(spark_submit_cmd) or os.path.exists(spark_submit_cmd)
    
    if not spark_submit_found:
        print("❌ Apache Spark spark-submit command not found.")
        print("Please ensure Apache Spark is installed and spark-submit is in your PATH.")
        sys.exit(1)
    
    print(f"🚀 Starting interactive Spark job: {job_type}")
    print(f"📝 Script: {script}")
    print(f"📂 Input: {input_path}")
    print(f"💾 Output: {output_path}")
    print(f"🌐 Spark UI will be available at: http://localhost:4042")
    print("=" * 60)
    print("Press Ctrl+C to stop the job and close the Spark UI")
    print("=" * 60)
    
    # Build command
    cmd = [spark_submit_cmd, script, input_path, output_path]
    env = os.environ.copy()
    env['PYSPARK_PYTHON'] = r'C:\Users\sarva\AppData\Local\Programs\Python\Python310\python.exe'
    env['JAVA_HOME'] = r'C:\Program Files\Eclipse Adoptium\jdk-17.0.17.10-hotspot'
    env['SPARK_HOME'] = r'C:\spark\spark-4.0.1-bin-hadoop3\spark-4.0.1-bin-hadoop3'
    env['HADOOP_HOME'] = r'C:\hadoop'
    
    # Print debug information
    print(f"[DEBUG] Command: {' '.join(cmd)}")
    print(f"[DEBUG] Working directory: {os.getcwd()}")
    print(f"[DEBUG] Script exists: {os.path.exists(script)}")
    print(f"[DEBUG] Input file exists: {os.path.exists(input_path)}")
    print(f"[DEBUG] SPARK_HOME: {env.get('SPARK_HOME')}")
    print(f"[DEBUG] JAVA_HOME: {env.get('JAVA_HOME')}")
    print(f"[DEBUG] HADOOP_HOME: {env.get('HADOOP_HOME')}")

    try:
        # Start the Spark job
        process = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, env=env, bufsize=1)
        
        print("\n📊 Spark job started! Check http://localhost:4042 for the Web UI")
        print("📝 Job output:")
        print("-" * 40)
        
        # Stream output in real-time
        while True:
            output = process.stdout.readline()
            if output == '' and process.poll() is not None:
                break
            if output:
                print(output.strip())
        
        # Get the return code
        return_code = process.poll()
        
        print("-" * 40)
        if return_code == 0:
            print("✅ Spark job completed successfully!")
        else:
            print(f"⚠️ Spark job finished with return code: {return_code}")
            
        print(f"🌐 Spark Web UI is still available at: http://localhost:4042")
        print("You can now access the stages page at: http://localhost:4042/stages/")
        print("\nPress Enter to close the Spark UI and exit...")
        input()
        
    except KeyboardInterrupt:
        print("\n\n⚠️ Interrupted by user. Stopping Spark job...")
        process.terminate()
        try:
            process.wait(timeout=10)
        except subprocess.TimeoutExpired:
            process.kill()
            process.wait()
        print("✅ Spark job stopped.")
    except Exception as e:
        print(f"❌ Error running Spark job: {e}")
        sys.exit(1)

if __name__ == "__main__":
    run_spark_job_interactive()