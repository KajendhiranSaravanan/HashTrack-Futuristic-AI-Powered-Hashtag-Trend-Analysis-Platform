import asyncio
import websockets
import json

async def test_websocket():
    uri = "ws://localhost:6000"
    try:
        async with websockets.connect(uri) as websocket:
            print("Connected to WebSocket server")
            # Wait for a few messages
            for i in range(5):
                message = await websocket.recv()
                data = json.loads(message)
                print(f"Received: {data}")
            print("WebSocket test completed successfully")
    except Exception as e:
        print(f"WebSocket connection failed: {e}")

# Run the test
asyncio.run(test_websocket())